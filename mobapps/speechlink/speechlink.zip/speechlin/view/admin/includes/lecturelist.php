            <table class="table-short">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td style="width: 25%;">Teacher Name</td> 					      					
						<td style="width: 20%;">Assign Class</td>
      					<td style="width: 25%;">Lecture</td> 
						<td style="width: 30%;">Action </td>
      				</tr>
      			</thead>      			
      			<tbody> 
					 <?php if(!empty($lecturelist)) {
						 $i = 1;
						 foreach($lecturelist as $lectures) { 
							 if($i%2 ==0){
							  $class="odd";
						  }else{
							  $class="even";
						  }
						   $lecture_id = base64_encode(base64_encode(base64_encode($lectures->lecture_id)));
						   $getlecture = getclassnameByID($lectures->class_id);
						   $getteachername = getteachernameByID($lectures->teacher_id);
					 ?>
      				<tr class="<?php echo $class; ?>">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first"><?php echo $getteachername; ?></td>					
      					<td class="col-first"><?php echo $getlecture; ?></td>					
      					<td class="col-first"><?php echo $lectures->lecture_name; ?></td>					
      					<td class="row-nav"><a Onclick="Editlecturename('<?php echo $lecture_id; ?>');" style="cursor: pointer;" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a Onclick="return deletelecture('<?php echo $lecture_id; ?>','<?php echo $lectures->lecture_name; ?>');"  class="table-delete-link" style="cursor: pointer;">Delete</a> <span class="hidden"></td>
      				</tr> 
				 <?php $i++;  } } ?>
      			</tbody>
				
      		</table> 	