                <div id='document_<?php echo $divsize; ?>' style="padding-top: 10px;">
						   <h3>Add Teacher by Fill All fields</h3>
							<ol id='documentlist_<?php echo $divsize; ?>' style="margin-bottom: 10px;">
								 <li class="even"><label class="field-title">Teacher Name<em>*</em>:</label><label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Teacher Name'" placeholder="Enter Teacher Name" id="teacher_name_<?php echo $divsize; ?>" name="teacher_name[]" /></label></li>
									<!--<li><label class="field-title">lecture<em>*</em>:</label>
									<label>
										<select class="classes_option" style="height: 28px;">
											<option selected>Select lecture&nbsp;</option>
											<option>Mathematics</option>
											<option>Science</option>
											<option>Dance</option>
											<option>Art</option>
											<option>Physical Education</option>
											<option>Basic Math</option>
											<option>Geometry</option>
											<option>Life Science</option>
											<option>Health</option>
											<option>Sports</option>
											<option>Social Science</option>
											<option>English</option>												
										</select>
									</label>
									</li>-->
								<li class="even"><label class="field-title">Gender <em>*</em>: </label> 
								   <label>
										<input name="gender[<?php echo $divsize; ?>]" checked="checked" id="gender_<?php echo $divsize; ?>" value="male" type="radio">Male 
										<input name="gender[<?php echo $divsize; ?>]" id="gender_<?php echo $divsize; ?>" value="female" type="radio">
										Female 
								   </label>
								   <span class="clearFix">&nbsp;</span>
								</li>
									
								<li>
								  <label class="field-title">Mobile No:</label><label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Mobile no'" placeholder="Enter Mobile no" name="mobile_number[]" id="mobile_number_<?php echo $divsize; ?>" /></label>
								</li>
								
								<li class="even">
								  <label class="field-title">Email Id<em>*</em>:</label><label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email ID'" placeholder="Enter Email ID" name="email[]"  id="email_<?php echo $divsize; ?>"/></label>
								</li>
								
								<!--<li><label class="field-title">Assign- Class<em>*</em>:</label>
								<label>
									<select class="classes_option" style="height: 28px;">
										<option selected>Select Class&nbsp;</option>
										<option>Nursery</option>
										<option>LKG</option>
										<option>UKG</option>
										<option>STD I</option>
										<option>STD II</option>
										<option>STD III</option>
										<option>STD IV</option>
										<option>STD V</option>
										<option>STD VI</option>
										<option>STD VII</option>
										<option>STD VIII</option>
										<option>STD IX</option>
										<option>STD X</option>
										<option>STD XI</option>
										<option>STD XII</option>
									</select>
								</label>
								</li>-->
								
								<li class="even">
								   <label class="field-title">Address<em>*</em>:</label><label>
								    <textarea  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" name="address[]" id="address_<?php echo $divsize; ?>" placeholder="Enter Address" rows="3" cols="25"></textarea></label>
								</li>
								
								<!--<li><input type="submit" name="submit" value="Submit" class="submit-btn" /></li>-->
						    </ol>
						 <span>
								<button type="button" id="add_new" class="submit-btn" onclick="teachershow('<?php echo  $divsize; ?>');" style="margin: 0px 6px 0px 6px;">Show</button> 
							    <button type="button" id="add_new" class="submit-btn"  onclick="teacherhide('<?php echo $divsize; ?>');"  style="margin: 0px 6px 0px 6px;">Hide</button>
							    <button type="button" id="removediv_<?php echo $divsize; ?>" class="submit-btn" onclick="removeteacherdiv('<?php echo $divsize; ?>');" >Remove</button>
							</span>	
				</div> 	