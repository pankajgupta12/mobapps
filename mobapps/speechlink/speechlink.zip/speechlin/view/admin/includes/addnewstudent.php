            <div id='document_<?php echo $divsize; ?>' style="padding-top: 10px;">
                  <h3>Add Student</h3>		
		        <ol id="documentlist_<?php echo $divsize; ?>" style="margin-bottom: 10px;">
						<li class="even">
							<label class="field-title">Student Name<em>*</em>:</label>
							<label><input class="txtbox-long" type="text" id="student_name<?php echo $divsize; ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Student Name'" placeholder="Enter Student Name" name="student_name[]" /></label>
						</li>
						
						<li>
							<label class="field-title">fathers Name<em>*</em>:</label>
							<label><input class="txtbox-long" type="text" id="std_father_name<?php echo $divsize; ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Father Name'" placeholder="Enter Father Name" name="std_father_name[]" /></label>
						</li>
						<li class="even">
							<label class="field-title">Gender <em>*</em>: </label> 
							<label><input name="gender[<?php echo $divsize; ?>]" checked="checked" id="gender<?php echo $divsize; ?>" value="male" type="radio"> Male 
							<input name="gender[<?php echo $divsize; ?>]" value="female" id="gender<?php echo $divsize; ?>" type="radio"> Female
							</label><span class="clearFix">&nbsp;</span>
						</li>
						
						<li>
						  <label class="field-title">Mobile No:</label>
						  <label><input class="txtbox-long" type="text" id="student_mobile_no<?php echo $divsize; ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Mobile no'" placeholder="Enter Mobile no" name="student_mobile_no[]" /></label>
						</li>
						
						<li class="even">
						  <label class="field-title">Email Id<em>*</em>:</label>
						  <label><input class="txtbox-long" type="text"  id="student_email<?php echo $divsize; ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email ID'" placeholder="Enter Email ID" name="student_email[]" /></label>
						</li>
						<?php  ?>
						<li>
							<label class="field-title">Class<em>*</em>:</label>
							<label>
								<select class="classes_option"  name="class[]" id="class<?php echo $divsize; ?>" style="height: 28px;">
									<option value="" selected>Select Class</option>
								<?php foreach($classlist as $key=>$class) { ?>	
									<option value="<?php echo $class->class_id;  ?>"><?php echo $class->classname;  ?></option>
									<?php  } ?>
								</select>
							</label>
						</li>
						
						<li class="even">
						   <label class="field-title">Address<em>*</em>:</label>
						   <label><textarea name="address[]" id="address<?php echo $divsize; ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" placeholder="Enter Address" rows="3" cols="25"></textarea></label>
						</li>
				</ol>	
		    
						<!--<li><<input type="submit" name="submit" value="Submit" class="submit-btn" /></li>-->
					<span>	
						    <button type="button" id="add_new" class="submit-btn" onclick="studentshow('<?php echo $divsize; ?>');" style="margin: 0px 6px 0px 6px;">Show</button> 
							<button type="button" id="add_new" class="submit-btn"  onclick="studenthide('<?php echo $divsize; ?>');"  style="margin: 0px 6px 0px 6px;">Hide</button>
							<button type="button" id="removediv_<?php echo $divsize; ?>" class="submit-btn" onclick="removeaddstudentdiv('<?php echo $divsize; ?>');" >Remove</button>
				    </span>
			</div>			