        <div class="box-container rounded_by_jQuery_corners add_by_fields">
		    <form action="<?php echo base_url('administration/add_Lecturee'); ?>" method="post" class="middle-forms">
 				<fieldset>  
					<h3>Edit Lecture by Fill All fields</h3>
				    <p>Please complete the form below. Mandatory fields marked <em>*</em></p>
					
				<?php  
			      //stdClass Object ( [lecture_id] => 2 [teacher_id] => 1 [class_id] => 4 [lecture_name] => Urdu [created_at] => 2017-01-05 02:39:31 ) 
				 //print_r($getlecturedata); 
				?>	
					<span id="updatemsgshow123" style="display:none; color:green;">One record has been update successfully</span>	
					
					<ol>
					
						<li class="even"><label class="field-title">Teacher Name<em>*</em>:</label>
						<label>
							<select class="classes_option" id="edit_teacher_id" name="edit_teacher_id" style="height: 28px;">
								<option value="" selected>Select Teacher&nbsp;</option>
							<?php foreach($teacherlist as $teachers) {  ?>	
								<option value="<?php echo $teachers->teacher_id; ?>" <?php if($teachers->teacher_id == $getlecturedata->teacher_id) { echo "selected"; }?>><?php echo $teachers->teacher_name; ?></option>
							<?php  } ?>					
							</select>
						</label>
						</li>
						<input type="hidden" id="lecture_id" value="<?php echo $getlecturedata->lecture_id; ?>">
						<li class="odd"><label class="field-title">Assign Class<em>*</em>:</label>
						<label>
							<select class="classes_option" id="edit_class_id" name="edit_class_id" style="height: 28px;">
								<option  value="" selected>Select Class&nbsp;</option>
							<?php foreach($classlist as $classdata) {  ?>	
								<option value="<?php echo $classdata->class_id; ?>" <?php if($classdata->class_id == $getlecturedata->class_id) { echo "selected"; }?>><?php echo $classdata->classname; ?></option>
							<?php  } ?>	
							</select>
						</label>
						</li>						
						
						 <li class="even"><label class="field-title">Lecture Name<em>*</em>:</label><label><input class="txtbox-long" id="edit_lecture_name" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Lecture Name'" placeholder="Enter Lecture Name" value="<?php echo $getlecturedata->lecture_name; ?>" name="edit_lecture_name" /></label></li>
						 
						<li> 
						  <input type="button" name="submit" id="submit" Onclick="updateLecture();" value="Update" class="submit-btn" />
					      <input type="button" name="submit" style="margin-right: 7px;" id="cancel" Onclick="CancelLecture();" value="Cancel" class="submit-btn" />
					   </li>
					</ol>
				</fieldset>
			</form>	
		</div>		