 <?php  //print_r($classlist); ?>
            <table class="table-short">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td>Class Name</td> 					      					
						<td style="padding-left: 26px;">Action </td>
      				</tr>
      			</thead>      			
      			<tbody>
					 <?php 
					 if(!empty($classlist)){
						 $i = 1;
							foreach($classlist as $valuedata) {
								 if($i%2 == 0) {
									 $clas = "odd";
								 }else{
									 $clas = "even";
								 }
						 $class_id = base64_encode(base64_encode(base64_encode($valuedata->class_id)));	 
					 ?>
								<tr class="<?php echo $clas; ?>">
									<td class="col-chk"><input type="checkbox"></td>
									<td class="col-first"><?php echo $valuedata->classname; ?></td>					
									<td class="row-nav"><a Onclick="Editclassname('<?php echo $class_id; ?>','<?php echo $valuedata->classname; ?>');" style="cursor: pointer;"  class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a Onclick="return deleteclassname('<?php echo $class_id; ?>','<?php echo $valuedata->classname; ?>');"  class="table-delete-link" style="cursor: pointer;" >Delete</a></td>
								</tr> 
						  <?php   $i++; }} ?>
      			</tbody>
				<tfoot>
      				<tr>
      					<td class="col-chk"></td>
      					<td colspan="4"><div class="align-right"><select class="form-select"><option value="option1" selected="selected">Bulk Options</option>
      					<option value="option2">Delete All</option></select>
      					</div></td>
      				</tr>
      			</tfoot>
      		</table>  	