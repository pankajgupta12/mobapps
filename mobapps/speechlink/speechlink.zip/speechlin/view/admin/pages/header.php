<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo $title; ?></title>
    <link href="<?php echo base_url();?>files/superadmin/css/reset.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url();?>files/superadmin/css/style.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url();?>files/superadmin/css/jquery.css" rel="stylesheet" type="text/css">
    <link href="<?php echo base_url();?>files/superadmin/css/colorbox.css" rel="stylesheet" type="text/css" media="screen">
    <link href="<?php echo base_url();?>files/superadmin/css/colorbox-custom.css"  media="screen" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url();?>files/superadmin/js/jquery.min.js"></script>
	<script>
	$(document).ready(function(){
		$(".teachers").click(function(){
			$("#modalBackgroundOverlay").show();
			$("#colorbox").show();
			
		});
		$("#modalClose").click(function(){
			$("#modalBackgroundOverlay").hide();
			$("#colorbox").hide();
			
		});
		
	});
	</script>
</head>
<body>
    <div id="container">
    <div id="header">
        <div id="top">
		  <h1><a href="<?php echo base_url('administration/dashbord');?>"><img src="<?php echo base_url();?>files/superadmin/images/logo.png" alt="Logo" width="100" /></a></h1>
		  <p id="userbox">Hello <strong><?php echo ucfirst($this->session->userdata('user_name')); ?></strong> &nbsp;| &nbsp;<a href="<?php echo base_url('administration/edit_profile');?>">Edit Profile</a> &nbsp;| &nbsp;<a href="<?php echo base_url('administration/logout');?>">Logout</a> <br>
		  <small>Last Login: <?php echo $this->session->userdata('logout_time'); ?></small></p>
		  <span class="clearFix">&nbsp;</span>
        </div>
      <ul id="menu">
	 
	    <li <?php if($this->uri->segment(2) == 'add_class') {?>class="selected" <?php  } ?>><a href="<?php echo base_url('administration/add_class');?>" style="background-position: 0px 0px;">Classes</a></li>
		
        <li <?php if($this->uri->segment(2) == 'dashbord' || $this->uri->segment(2) == 'add_student') {?>class="selected" <?php  } ?>><a href="<?php echo base_url('administration/dashbord');?>" style="background-position: 0px 0px;">Students  </a></li>     
		
        <li <?php if($this->uri->segment(2) == 'teachers' || $this->uri->segment(2) == 'add_teacher') {?>class="selected" <?php  } ?>><a href="<?php echo base_url('administration/teachers');?>" style="background-position: 0px 0px;">Teachers</a></li>
        
        <li <?php if($this->uri->segment(2) == 'add_lecture') {?>class="selected" <?php  } ?>><a href="<?php echo base_url('administration/add_lecture');?>" style="background-position: 0px 0px;">Lecture</a></li>  
      </ul>	
      <span class="clearFix">&nbsp;</span>
    </div>