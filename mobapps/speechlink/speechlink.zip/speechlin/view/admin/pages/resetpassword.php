
<div id="contents">
	<div id="content-top">
    <h2>Change Password</h2>      
      <span class="clearFix">&nbsp;</span>
      </div>      
      <div id="mid-col">     	
      	<div class="box">
			<h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">Change Password</h4>
			
			 <?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
			<?php  }?> 	
			<?php if( $this->session->flashdata('error') ){ ?>
				<div class="alert alert-danger">
				  <strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
				</div>
			<?php  }?> 
			
      		<form action="<?php echo base_url('administration/resetpassword');  ?>" method="post" name="reset" class="reset_form">
				<fieldset>
      					<ol>
						    <li class="even">
							   <label class="field-title">Old Password:</label> 
							    <label><input class="txtbox-shorts" type="password"  name="old_password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Old Password'" placeholder="Enter Old Password" value="<?php  if(set_value('old_password')){echo set_value('old_password');  } ?>" >
							    </label>
							     <span class="error"><?php  echo   form_error('old_password'); ?></span> 
								 
							</li>
							 
      						<li class="even">
							   <label class="field-title">New Password:</label> 
							      <label><input class="txtbox-shorts"  type="password"  name="new_password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter New Password'" placeholder="Enter New Password" value="<?php  if(set_value('new_password')){echo set_value('new_password');  } ?>">
							   </label>
							    <span class="error"><?php  echo   form_error('new_password'); ?></span> 
							</li>
							
      						<li class="even">
							   <label class="field-title">Confirm Password:</label> 
							      <label><input class="txtbox-shorts" type="password"  name="confirm_password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Confirm Password'" placeholder="Enter Confirm Password" value="<?php // if(set_value('confirm_password')){echo set_value('confirm_password');  } ?>">
							     </label>
								 <span class="error"><?php  echo   form_error('confirm_password'); ?></span> 
							</li>
							
      						<li class="even"><input type="submit" name="submit" value="Update" class="btns" /></li>			 						
      					</ol>
      			</fieldset>
			</form>        
      	</div>      
      </div>            
      <span class="clearFix">&nbsp;</span>     
</div>
</div>
<style>
 .error{
	 color:red;
 }
</style>
