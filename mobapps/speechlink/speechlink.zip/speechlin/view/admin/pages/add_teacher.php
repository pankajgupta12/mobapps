    <div id="content">
	    <div id="content-top">
         <h2>Add Teacher</h2>
         <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
          <span class="clearFix">&nbsp;</span>
        </div>        
        <div id="mid-col">	
	    <div class="box">
	        <h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;"> Add Teacher <span class="teachers"><img src="<?php echo base_url();?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/teachers');?>" style="color: #a5ce4a;text-decoration: none;">Teacher List</a></span></h4>
			
			<?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
			<?php  }?> 	
			<?php if( $this->session->flashdata('error') ){ ?>
				<div class="alert alert-danger">
				  <strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
				</div>
			<?php  }?> 
		    <div class="box-container rounded_by_jQuery_corners add_by_fields">		
			    <form action="<?php echo base_url('administration/add_teacher'); ?>" id="add_teacher" method="post" class="middle-forms">
					<fieldset> 
						<div id='document_0'>
						   <h3>Add Teacher by Fill All fields</h3>
							<ol id='documentlist_0' style="margin-bottom: 10px;">
								<li class="even"><label class="field-title">Teacher Name<em>*</em>:</label><label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Teacher Name'" placeholder="Enter Teacher Name" id="teacher_name_0" name="teacher_name[]" /></label></li>
									<!--<li><label class="field-title">lecture<em>*</em>:</label>
									<label>
										<select class="classes_option" style="height: 28px;">
											<option selected>Select lecture&nbsp;</option>
											<option>Mathematics</option>
											<option>Science</option>
											<option>Dance</option>
											<option>Art</option>
											<option>Physical Education</option>
											<option>Basic Math</option>
											<option>Geometry</option>
											<option>Life Science</option>
											<option>Health</option>
											<option>Sports</option>
											<option>Social Science</option>
											<option>English</option>												
										</select>
									</label>
									</li>-->
								<li class="even"><label class="field-title">Gender <em>*</em>: </label> <label>
									<input name="gender[0]" checked="checked"  id="gender_0" value="male" type="radio">
									Male <input name="gender[0]" value="female" id="gender_0" type="radio">
									Female </label><span class="clearFix">&nbsp;</span>
								</li>
									
								<li>
								  <label class="field-title">Mobile No:</label><label><input class="txtbox-long" type="text" onkeyup="integersOnly(this)"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Mobile no'" placeholder="Enter Mobile no" name="mobile_number[]" id="mobile_number_0"/></label>
								</li>
								
								<li class="even">
								  <label class="field-title">Email Id<em>*</em>:</label><label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email ID'" placeholder="Enter Email ID" name="email[]" id="email_0" /></label>
								</li>
								
								<!--<li><label class="field-title">Assign- Class<em>*</em>:</label>
								<label>
									<select class="classes_option" style="height: 28px;">
										<option selected>Select Class&nbsp;</option>
										<option>Nursery</option>
										<option>LKG</option>
										<option>UKG</option>
										<option>STD I</option>
										<option>STD II</option>
										<option>STD III</option>
										<option>STD IV</option>
										<option>STD V</option>
										<option>STD VI</option>
										<option>STD VII</option>
										<option>STD VIII</option>
										<option>STD IX</option>
										<option>STD X</option>
										<option>STD XI</option>
										<option>STD XII</option>
									</select>
								</label>
								</li>-->
								
								<li class="even">
								   <label class="field-title">Address<em>*</em>:</label><label><textarea name="address[]" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" placeholder="Enter Address" rows="3" id="address_0" cols="25"></textarea></label>
								</li>
								
								<!--<li><input type="submit" name="submit" value="Submit" class="submit-btn" /></li>-->
						    </ol>
						    <span>
								<button type="button" id="add_new" class="submit-btn" onclick="teachershow(0);" style="margin: 0px 6px 0px 6px;">Show</button> 
								<button type="button" id="add_new" class="submit-btn"  onclick="teacherhide(0);" style="margin: 0px 6px 0px 6px;">Hide</button>
								
								<button type="button" id="add_new" class="submit-btn" onclick="removeteacherdiv(0);" style="margin: 0px 6px 0px 6px;">Remove</button>
							</span>	
						</div> 	
						<div class="add_new_teacher hide"></div>
						<button type="button" id="add_new" class="submit-btn" onclick="addteacher();" style="margin-right: 5px;" >Add Teacher</button>
						<button type="submit" name="submit" id="studentbtn" class="submit-btn"  style="float: left;">submit</button>
				    </fieldset>
			    </form>
            </div>     
			
			<div class="Add_from_files">
				<h2>Import CSV File of Teacher List</h2>
				<form action="<?php  echo base_url('administration/teacher_csvfile'); ?>"  method="post"  enctype="multipart/form-data" class="middle-forms">
				   <input class="upload_file" type="file" name="file" id="fileupload" onChange="profileimagevalidation(this.value);preview(this);" accept=".csv" />
				  <input type="submit" name="submit" class="submit-btn add_file" value="Submit" />
				</form>		
			</div>
        </div>            
        </div>            
      <span class="clearFix">&nbsp;</span>     
    </div>
	    <style>
			 .error{
				 color:red;
			 }
		</style>
		<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script>
		function removeteacherdiv(div_id){
		//	alert(div_id);
			$('#document_'+div_id).addClass('hide disabled');
			$('#document_'+div_id).html('');
			$('#document_'+div_id+' input').remove();
			$('#document_'+div_id).attr('style','');
		}
		
		function teachershow(div_id){
		   $('#documentlist_'+div_id).show();
		}	
		
		function teacherhide(div_id){
			$('#documentlist_'+div_id).hide();
		}	
		
		function addteacher() {
			
				$('.add_new_teacher').removeClass('hide');
				$('.alert-success').hide();	
				var divSize = $(".add_new_teacher > div").size()+1;
				var	div = divSize - 1;
				//teacher_name_0    mobile_number_0 email_0  address_0
				var teachername = $('#teacher_name_'+div).val();
				var mobile_number = $('#mobile_number_'+div).val();
				var email = $('#email_'+div).val();
				var address = $('#address_'+div).val();
			 
			 
				if(teachername == "" ||  mobile_number == "" || email == "" || address == ""){
					 alert ('Please fill all fields');
					 $('#documentlist_'+div).show();
					 return false;
				}	
				 
				$.ajax({
						url: '<?php echo base_url(); ?>administration/addteacher',
						type: 'POST',
						data: {divSize:divSize},
						success: function(res)
						{
							if(divSize=='0'){
								$('.add_new_teacher').html(res);
							}else{
								$('.add_new_teacher').append(res);
							}
						}
				});
		}
		
	    $(function() {
			$('button[id="studentbtn"]').on('click', function() {
				$('button[id="studentbtn"]').addClass('disabled');
				resetErrors();
				var url = $('#add_teacher').attr('action');
				var formData=$('#add_teacher').serialize();
				$.ajax({
						dataType: 'json',
						type: 'POST',
						url: url,
						data: formData,
						success: function(resp) {
							//console.log(resp);
							
							if(resp.done==='success'){
								
								$('button[id="studentbtn"]').removeClass('disabled');
								window.location.href = "<?php echo base_url('administration/teachers'); ?>";
								// if(resp.set_submit=='1')
								// {
									//alert(resp.set_submit);
									// // $("#is_submit").val('1');
									// $('#work_order_form').submit();
									// return true;
								// }				
							}else{
								if (resp === true) {
									//successful validation
									$('button[id="studentbtn"]').removeClass('disabled');
									$('#work_order_form').submit();

								} else {
									$('#pageloaddiv').hide();
									$('button[id="studentbtn"]').removeClass('disabled');
									$.each(resp, function(i, v) {
									console.log(i + " => " + v); // view in console for error messages
									var msg = '<label class="error" for="'+i+'">'+v+'</label>';
									$('input[name="' + i + '"],input[id="' + i + '"],select[id="' + i + '"],div[id="' + i + '"],textarea[id="' + i + '"]').addClass('inputTxtError').after(msg);
									});

									var keys = Object.keys(resp);
									$('[name="'+keys[0]+'"]').focus();
								}
							}

						},
						error: function() {
							console.log('there was a problem checking the fields');
						}
					});
					return false;
				});
		});
		
			function resetErrors() {
				$('form input,#vendor_id_chosen,form textarea,div.chosen-container').removeClass('inputTxtError');
				$('label.error').remove();
			}	
			
		var integer_only_warned = false;
						function integersOnly(obj) {
							var value_entered = obj.value;
							if (!integer_only_warned) {
								if (value_entered.indexOf(".") > -1) {
									alert('Please enter an integer only. No decimal places.');
									integer_only_warned = true;
									obj.value = value_entered.replace(/[^0-9]/g,'');
								}
							}
							obj.value = value_entered.replace(/[^0-9]/g,'');        
						}	
		
 	</script>