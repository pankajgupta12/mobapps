    <div id="content">
	    <div id="content-top">
         <h2>Add Class</h2>
         <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
          <span class="clearFix">&nbsp;</span>
        </div>        
        <div id="mid-col">	
	    <div class="box">
	        <h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;"> Add Class <!--<span class="teachers"><img src="<?php echo base_url();?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/classes');?>" style="color: #a5ce4a;text-decoration: none;">Class List</a></span>--></h4>
			
			
		    <div class="box-container rounded_by_jQuery_corners add_by_fields" id="submitclass">		
			    <form action="" method="post" class="middle-forms">				
				<fieldset>
					<h3>Add Class by Fill All fields</h3>
					<p>Please complete the form below. Mandatory fields marked <em>*</em></p>
					<span id="messageshow" style="display:none; color:green;">One class name added successfully</span>
					<span id="deletemsgshow" style="display:none; color:red;">One row delete successfully</span>
					<ol>
					  <li class="even">
					    <label class="field-title">Class Name<em>*</em>:</label>
						  <label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Class Name'" placeholder="Enter Class Name" id="claas_name" name="claas_name" /></label>
					  </li>
					
					  <li>
					    <input type="button" name="submit" id="submit" Onclick="Addclass();" value="Submit" class="submit-btn" />
					  </li>
					</ol>
				</fieldset>
			</form>
            </div>

         <div class="box-container rounded_by_jQuery_corners add_by_fields" id="updateclass" style="display:none;">		
			<form action="" method="post" class="middle-forms">				
				<fieldset>
					<h3>Edit Class by Fill All fields</h3>
					<p>Please complete the form below. Mandatory fields marked <em>*</em></p>
					<span id="messageshow" style="display:none; color:green;">One class name added successfully</span>
					<span id="updatemsgshow" style="display:none; color:green;">One record has been update successfully</span>
					<span id="deletemsgshow" style="display:none; color:red;">One row delete successfully</span>
					<ol>
					  <li class="even">
					    <label class="field-title">Class Name<em>*</em>:</label>
						  <label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Class Name'" placeholder="Enter Class Name" id="editclaas_name" name="claas_name" /></label>
						  
						 <input type="hidden" name="classid" id="classid" > 
					  </li>
					
					  <li>
					    <input type="button" name="submit" id="submit" Onclick="updateclassdata();" value="Update" class="submit-btn" />
					   <input type="button" name="submit" style="margin-right: 7px;" id="cancel" Onclick="Cancelclass();" value="Cancel" class="submit-btn" />
						
					  </li>
					</ol>
				</fieldset>
			</form>
            </div>			
			
			<div class="Add_from_files">
			<?php // print_r($classlist);  ?>
				<h2>Class List</h2>
				<table class="table-short" id="getdata">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td>Class Name</td> 					      					
						<td style="padding-left: 26px;">Action </td>
      				</tr>
      			</thead>      			
      			<tbody>
				 <?php 
				 if(!empty($classlist)){
					 $i = 1;
					  foreach($classlist as $valuedata) {
					 if($i%2 == 0) {
						 $clas = "odd";
					 }else{
						 $clas = "even";
					 }
				 $class_id = base64_encode(base64_encode(base64_encode($valuedata->class_id)));			 
				 ?>
      				<tr class="<?php echo $clas; ?>">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first"><?php echo $valuedata->classname; ?></td>					
      					<td class="row-nav"><a Onclick="Editclassname('<?php echo $class_id; ?>','<?php echo $valuedata->classname; ?>');" style="cursor: pointer;" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a  Onclick="return deleteclassname('<?php echo $class_id; ?>','<?php echo $valuedata->classname; ?>');"  class="table-delete-link" style="cursor: pointer;">Delete</a> </td>
      				</tr> 
					  <?php   $i++; } }else{ ?>
					  <tr class="odd"><td class="col-chk" colspan="10">No record found </td></tr> 
					  <?php  } ?>
      			</tbody>
				<tfoot>
      				<tr>
      					<td class="col-chk"></td>
      					<td colspan="4"><div class="align-right"><select class="form-select"><option value="option1" selected="selected">Bulk Options</option>
      					<option value="option2">Delete All</option></select>
      					</div></td>
      				</tr>
      			</tfoot>
      		</table>  		
			</div>
        </div>            
        </div>            
      <span class="clearFix">&nbsp;</span>     
    </div>
	
 <script>
        function Addclass(){
		  var classname = $('#claas_name').val();
		   if(classname == "" || classname == null){
			   alert('Class name field is required.');
			   return false;
		   }
		   var formData = "classname="+classname;
		//   alert(formData);
		     $.ajax({
						type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
						url         : '<?php echo base_url('administration/insertclass'); ?>', // the url where we want to POST
						data        : formData, // our data object
						dataType    : 'html', // what type of data do we expect back from the server
						
						success: function(data)
					   {
						   
						 //  alert(data); // show response from the php script.
						   $('#claas_name').val('');
						   $('#getdata').html(data);
						   $('#messageshow').show();
						   $('#messageshow').fadeOut(1500);
					   }	
                });
	    }
		
		function deleteclassname(classid,classname){

			if(confirm("Are you sure do you want delete class "+classname)){
				   var formData = "class_id="+classid;
				//   alert(formData);
					 $.ajax({
								type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
								url         : '<?php echo base_url('administration/delete_class'); ?>', 
								data        : formData, // our data object
								dataType    : 'html', // what type of data do we expect back from the server
								
								success: function(data)
							   {
								   
								 //  alert(data); // show response from the php script.
								   $('#claas_name').val('');
								   $('#getdata').html(data);
								   $('#deletemsgshow').show();
								   $('#deletemsgshow').fadeOut(1500); 
							   }	
						});
				}else{
					  return false;
				}
		}
		
		function Editclassname(classid,classname){
			
			$('#updateclass').show();
			$('#submitclass').hide();
			$('#editclaas_name').val(classname);
			$('#classid').val(classid);
		}
		
		function Cancelclass(){
			$('#updateclass').hide();
			$('#submitclass').show();
		}
		
		function updateclassdata(){
			
			var editclaasname = $('#editclaas_name').val();
			var classid = $('#classid').val();
			
			if(editclaasname == "" || editclaasname == null){
			   alert('Class name field is required.');
			   return false;
		   }
			
		    var formData = "classid="+classid+'&editclaasname='+editclaasname;
		//   alert(formData);
		     $.ajax({
						type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
						url         : '<?php echo base_url('administration/updateclassdata'); ?>', 
						data        : formData, // our data object
						dataType    : 'html', // what type of data do we expect back from the server
						
						success: function(data)
					   {
						   $('#getdata').html(data);
						  // $('#submitclass').show();
						   $('#updatemsgshow').show();
						   $('#updatemsgshow').fadeOut(1500);  
					   }	
                }); 
		}
		
	     	
		
		
 </script>	
		