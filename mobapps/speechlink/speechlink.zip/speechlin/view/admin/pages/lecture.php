<div id="content">
	<div id="content-top">
    <h2>Examination</h2>
      <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
      <span class="clearFix">&nbsp;</span>
      </div>      
      <div id="mid-col">     	
      	<div class="box">
      		<h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">All Lecture<span class="teachers"><img src="<?php echo base_url(); ?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/add_lecture');?>" style="color: #a5ce4a;text-decoration: none;">Add Lecturer</a></span></h4>
        <div class="box-container rounded_by_jQuery_corners" style="border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;">     		
      		<table class="table-short">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td>Lectur Name</td>
      					<td>Teacher address</td>
						<td>Assign Class</td>
      					<td>Action:<select><option>Active</option>
						<option>Inactive</option>
						</select>						
						</td>
      				</tr>
      			</thead>      			
      			<tbody>
      				<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Mathematics</td>
      					<td class="col-second">Thelma Egbert</td>
						<td class="col-third">Nursery</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      				<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Science</td>
      					<td class="col-second">Frances Greeves</td>
						<td class="col-third">LKG</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      				<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Music</td>
      					<td class="col-second">Moneaka Elam</td>
						<td class="col-third">UKG</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      				<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Dance</td>
      					<td class="col-second">Lucy Harshbarger</td>
						<td class="col-third">STD I</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      				<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Art</td>
      					<td class="col-second">Lela Dickey</td>
						<td class="col-third">STD II</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Physical Education</td>
      					<td class="col-second">Olivia Mitchell</td>
						<td class="col-third">STD III</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Basic Math</td>
      					<td class="col-second">Lotus Jacob</td>
						<td class="col-third">STD IV</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Geometry</td>
      					<td class="col-second">Betty Williams</td>
						<td class="col-third">STD V</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Life Science</td>
      					<td class="col-second">Anne Kemper</td>
						<td class="col-third">STD VI</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      				<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Health</td>
      					<td class="col-second">Jean Rash</td>
						<td class="col-third">STD VII</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr  class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Woodshop</td>
      					<td class="col-second">Mary Hill</td>
						<td class="col-third">STD VIII</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      				<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Sports</td>
      					<td class="col-second">Mary E. Elam</td>
						<td class="col-third">STD IX</td>
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
      			</tbody>
				<tfoot>
      				<tr>
      					<td class="col-chk"></td>
      					<td colspan="4"><div class="align-right"><select class="form-select"><option value="option1" selected="selected">Bulk Options</option>
      					<option value="option2">Delete All</option></select>
      					</div></td>
      				</tr>
      			</tfoot>
      		</table>  	
      	</div>
      	</div>      
      </div>            
      <span class="clearFix">&nbsp;</span>     
</div>
</div>
