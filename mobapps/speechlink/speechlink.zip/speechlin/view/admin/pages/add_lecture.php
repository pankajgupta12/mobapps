    <?php  
	
	/* print_r($classlist);
	echo "<br>";echo "<br>";
	print_r($teacherlist);
 */

	?>
	<div id="content">
	    <div id="content-top">
         <h2>Add Lecture</h2>
         <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
          <span class="clearFix">&nbsp;</span>
        </div>        
        <div id="mid-col">	
	    <div class="box">
	        <h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;"> Add Lecture <!--<span class="teachers"><img src="<?php echo base_url();?>files/superadmin/images/plus.png" /><a href="<?php //echo base_url('administration/lecture');?>" style="color: #a5ce4a;text-decoration: none;">Lecture List</a></span>--></h4>
			
			<?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
			<?php  }?> 	
			<?php if( $this->session->flashdata('error') ){ ?>
				<div class="alert alert-danger">
				  <strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
				</div>
			<?php  }?> 
		    <div class="box-container rounded_by_jQuery_corners add_by_fields" id="addformlecture">		
		       <form action="<?php echo base_url('administration/add_Lecturee'); ?>" method="post" class="middle-forms">				
				<fieldset>  
					<h3>Add Lecture by Fill All fields</h3>
				    <p>Please complete the form below. Mandatory fields marked <em>*</em></p>
					
					<span id="messageshow" style="display:none; color:green;">One lecture  added successfully</span>
					<span id="updatemsgshow" style="display:none; color:green;">One record has been update successfully</span>
					<span id="deletemsgshow" style="display:none; color:red;">One row delete successfully</span>
					
					<ol>
					
						<li class="even"><label class="field-title">Teacher Name<em>*</em>:</label>
						<label>
							<select class="classes_option" id="teacher_id" name="teacher_id" style="height: 28px;">
								<option value="" selected>Select Teacher&nbsp;</option>
							<?php foreach($teacherlist as $teachers) {  ?>	
								<option value="<?php echo $teachers->teacher_id; ?>"><?php echo $teachers->teacher_name; ?></option>
							<?php  } ?>					
							</select>
						</label>
						</li>
						
						<li class="odd"><label class="field-title">Assign Class<em>*</em>:</label>
						<label>
							<select class="classes_option" id="class_id" name="class_id" style="height: 28px;">
								<option  value="" selected>Select Class&nbsp;</option>
							<?php foreach($classlist as $classdata) {  ?>	
								<option value="<?php echo $classdata->class_id; ?>"><?php echo $classdata->classname; ?></option>
							<?php  } ?>	
							</select>
						</label>
						</li>						
						
						 <li class="even"><label class="field-title">Lecture Name<em>*</em>:</label><label><input class="txtbox-long" id="lecture_name" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Lecture Name'" placeholder="Enter Lecture Name" name="lecture_name" /></label></li>
						 
						<li> <input type="button" name="submit" id="submit" Onclick="addlecture();" value="Submit" class="submit-btn" /></li>
					</ol>
				</fieldset>
			</form>    
			</div>
			<span id="showeditpart">
			       
				<div id="updatelecture">
				 
				</div>
			</span>
			<div class="Add_from_files">
			<?php // print_r($classlist);  ?>
				<h2>Lecture List</h2>
			<table class="table-short" id="getlecturedata">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td style="width: 25%;">Teacher Name</td> 					      					
						<td style="width: 20%;">Assign Class</td>
      					<td style="width: 25%;">Lecture</td> 
						<td style="width: 30%;">Action </td> 
      				</tr>
      			</thead>      			
      			<tbody> 
				 <?php if(!empty($lecturelist)) {
					 $i =1;
				 foreach($lecturelist as $lectures) { 
				  if($i%2 ==0){
					  $class="odd";
				  }else{
					  $class="even";
				  }
				  $lecture_id = base64_encode(base64_encode(base64_encode($lectures->lecture_id)));	
				  $getlecture = getclassnameByID($lectures->class_id);
				  $getteachername = getteachernameByID($lectures->teacher_id);
				//  print_r($val);
				 ?>
      				   <tr class="<?php echo $class; ?>">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first"><?php echo $getteachername; ?></td>					
      					<td class="col-first"><?php echo $getlecture; ?></td>					
      					<td class="col-first"><?php echo $lectures->lecture_name; ?></td>					
      					<td class="row-nav"><a Onclick="Editlecturename('<?php echo $lecture_id; ?>');" style="cursor: pointer;" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a Onclick="return deletelecture('<?php echo $lecture_id; ?>','<?php echo $lectures->lecture_name; ?>');"  class="table-delete-link" style="cursor: pointer;" >Delete</a> <span class="hidden"></td>
      				</tr> 
				 <?php  $i++; } } else{?>
				<tr class="odd"> <td class="col-chk" colspan="10">No Records found</td></tr>
				 <?php  } ?>
      			</tbody>
				
      		</table> 		
			</div>
        </div>            
        </div>            
      <span class="clearFix">&nbsp;</span>     
    </div>
	<script>
	    
	  function addlecture(){
		  var teacherid = $('#teacher_id').val();
		  var classid = $('#class_id').val();
		  var lecturename = $('#lecture_name').val();
		   if(teacherid == "" || teacherid == null){
			   alert('Teacher name field is required.');
			   $('#teacher_id').focus();
			   return false;
		   }
		   if(classid == "" || classid == null){
			   alert('Class name field is required.');
			   $('#class_id').focus();
			   return false;
		   }
		    if(lecturename == "" || lecturename == null){
			   alert('Lecture name field is required.');
			   $('#lecture_name').focus();
			   return false;
		   }
		   var formData = "teacherid="+teacherid+'&classid='+ classid +'&lecturename='+lecturename;
		//   alert(formData);
		     $.ajax({
						type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
						url         : '<?php echo base_url('administration/add_lecturedata'); ?>', 
						data        : formData, // our data object
						dataType    : 'html', // what type of data do we expect back from the server
						
						success: function(data)
					   {
						    //alert(data);
							$('#getlecturedata').html(data);
							$('#teacher_id').val('');
							$('#class_id').val('');
							$('#lecture_name').val('');
							$('#messageshow').show();
						    $('#messageshow').fadeOut(1500);
						/*  //  alert(data); // show response from the php script.
						   $('#claas_name').val('');
						   $('#getdata').html(data);
						   $('#messageshow').show();
						   $('#messageshow').fadeOut(1500); */
					   }	
                });
	    }
		
		function deletelecture(lectureid,lecturename){

			if(confirm("Are you sure do you want delete lecture "+lecturename)){
				   var formData = "lectureid="+lectureid;
				//   alert(formData);
					 $.ajax({
								type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
								url         : '<?php echo base_url('administration/delete_lecture'); ?>', 
								data        : formData, // our data object
								dataType    : 'html', // what type of data do we expect back from the server
								
								success: function(data)
							   {
								   
								 //  alert(data); // show response from the php script.
								//   $('#claas_name').val('');
								   $('#getlecturedata').html(data);
								    $('#showeditpart').hide();
				                    $('#addformlecture').show();
								    $('#deletemsgshow').show();
								   $('#deletemsgshow').fadeOut(1500);  
							   }	
						});
				}else{
					  return false;
				}
		}


		function Editlecturename(lectureid){
			   /*  $('#updatelecture').show();
				$('#addformlecture').hide(); */
				
				var formData = "lectureid="+lectureid;
				//   alert(formData);
					 $.ajax({
								type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
								url         : '<?php echo base_url('administration/Editlecturename'); ?>', 
								data        : formData, // our data object
								dataType    : 'html', // what type of data do we expect back from the server
								
								success: function(data)
							   {
								   
								 //  alert(data); // show response from the php script.
								//   $('#claas_name').val('');
								   $('#updatelecture').html(data);
								   $('#addformlecture').hide();
								   $('#showeditpart').show();
								
							   }	
						});
				
		}	

		function CancelLecture(){
				$('#showeditpart').hide();
				$('#addformlecture').show();
		}	
		
	 function updateLecture(){
		         
		 
		  var lectureid = $('#lecture_id').val();
		  var teacherid = $('#edit_teacher_id').val();
		  var classid = $('#edit_class_id').val();
		  var lecturename = $('#edit_lecture_name').val();
		   if(teacherid == "" || teacherid == null){
			   alert('Teacher name field is required.');
			   $('#teacher_id').focus();
			   return false;
		   }
		   if(classid == "" || classid == null){
			   alert('Class name field is required.');
			   $('#class_id').focus();
			   return false;
		   }
		    if(lecturename == "" || lecturename == null){
			   alert('Lecture name field is required.');
			   $('#lecture_name').focus();
			   return false;
		   }
		   var formData = "teacherid="+teacherid+'&classid='+ classid +'&lecturename='+lecturename+'&lectureid='+lectureid;
		//   alert(formData);
		        $.ajax({
						type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
						url         : '<?php echo base_url('administration/updatelacture'); ?>', 
						data        : formData, // our data object
						dataType    : 'html', // what type of data do we expect back from the server
						
						success: function(data)
					   {
						    $('#updatemsgshow123').show();
							$('#updatemsgshow123').fadeOut(1500);
							$('#getlecturedata').html(data);
							
					   }	
                    });
		 
	 }	
		
	</script>
		