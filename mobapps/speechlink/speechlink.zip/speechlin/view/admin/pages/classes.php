<div id="content">
	<div id="content-top">
    <h2>Classes</h2>
      <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
      <span class="clearFix">&nbsp;</span>
      </div>      
      <div id="mid-col">     	
      	<div class="box">
      		<h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">All Classes <span class="teachers"><img src="<?php echo base_url(); ?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/add_class');?>" style="color: #a5ce4a;text-decoration: none;">Add Class</a></span></h4>
        <div class="box-container rounded_by_jQuery_corners" style="border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;">     		
      		<table class="table-short">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td>Class Name</td> 					      					
						<td>Date/Time</td>
      					<td>Action:<select><option>Active</option>
						<option>Inactive</option>
						</select>						
						</td>
      				</tr>
      			</thead>      			
      			<tbody>
      				<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">Nursery</td>					
      					<td class="col-third">10-12-2016 | 09:10AM</td>					
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr> 
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">LKG</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr> 
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">UKG</td>      				
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr> 
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD I</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD II</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD III</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD IV</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD V</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD VI</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD VII</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD VIII</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD XI</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr class="odd">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD XI</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					<tr>
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first">STD XII</td>      					
      					<td class="col-third">10-12-2016 | 09:10AM</td>						
      					<td class="row-nav"><a href="#" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">Delete</a> <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
					
      			</tbody>
				<tfoot>
      				<tr>
      					<td class="col-chk"></td>
      					<td colspan="4"><div class="align-right"><select class="form-select"><option value="option1" selected="selected">Bulk Options</option>
      					<option value="option2">Delete All</option></select>
      					</div></td>
      				</tr>
      			</tfoot>
      		</table>  	
      	</div>
      	</div>      
      </div>            
      <span class="clearFix">&nbsp;</span>     
</div>