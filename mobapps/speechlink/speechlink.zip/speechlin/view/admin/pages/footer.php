

<div id="footer-wrap">
	<div id="footer">        
        <div id="footer-bottom">
        	<p>Copyright © 2016 School.All Rights Reserved.</p>
        </div>
        
	</div>
</div>
	</body>
	</html>