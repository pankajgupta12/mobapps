
    <div id="content">
	  <div id="content-top">
     <h2>Teachers</h2>
	 <?php // print_r($teacherlist);  ?>
      <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
      <span class="clearFix">&nbsp;</span>
      </div>      
      <div id="mid-col">     	
      	<div class="box">
      		<h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">All Teachers <span class="teachers"><img src="<?php echo base_url(); ?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/add_teacher');?>" style="color: #a5ce4a;text-decoration: none;">Add Teacher</a></span></h4>
        <div class="box-container rounded_by_jQuery_corners" style="border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;">  
        
		 <?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
		<?php  }?> 	
    		
      		<table class="table-short">
      			<thead>
      				<tr>
      					<td>&nbsp;</td>
      					<td>Teacher Name</td>
      					<td>Email address</td>
						<td>Gender</td>
						<td>Action </td>
      				</tr>
      			</thead>      			
      			<tbody>
					<?php 

                if(!empty($teacherlist)) {   
					$i=1; foreach($teacherlist as $key=>$teacher) { 
						
						if($i%2 == 0){
							$bgcolor = 'even';
						}else{
							$bgcolor = 'odd';
						}
				 $teacher_id = base64_encode(base64_encode(base64_encode($teacher->teacher_id)));		
					?>	
      				<tr class="<?php echo $bgcolor; ?>">
      					<td class="col-chk"><input type="checkbox"></td>
      					<td class="col-first"><?php echo $teacher->teacher_name;  ?></td>
      					<td class="col-second"><?php echo $teacher->email;  ?></td>
						<td class="col-third"><?php echo $teacher->gender;  ?></td>
      					<td class="row-nav"><a href="<?php echo base_url('administration/edit_teacher?teacher_id='.$teacher_id);?>" class="table-edit-link">Edit</a> <span class="hidden"> | </span> <a href="<?php echo base_url('administration/delete_teacher?teacher_id='.$teacher_id);?>" Onclick="return confirm('Are you sure do you want delete records of <?php echo $teacher->teacher_name;  ?>');" class="table-delete-link">Delete</a>  <span class="hidden"> | </span> <a href="#" class="table-delete-link">View</a></td>
      				</tr>
				<?php $i++; } }else{ ?>
      				<tr><td class="col-chk" colspan="10">No records found </td></tr>
				<?php  } ?>
      			</tbody>
				<tfoot>
      				<tr>
      					<td class="col-chk"></td>
      					<td colspan="5"><div class="align-right"><select class="form-select"><option value="option1" selected="selected">Bulk Options</option>
      					<option value="option2">Delete All</option></select>
      					</div></td>
      				</tr>
      			</tfoot>
      		</table>  	
      	</div>
      	</div>      
      </div>            
      <span class="clearFix">&nbsp;</span>     
</div>
</div>
