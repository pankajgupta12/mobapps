    <div id="content">
	    <div id="content-top">
         <h2>Edit Students</h2>
         <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
          <span class="clearFix">&nbsp;</span>
        </div>        
        <div id="mid-col">
		   
		<?php // print_r($getstudentdata); 
    $student_id = base64_encode(base64_encode(base64_encode($getstudentdata->student_id))); 
		?>
	    <div class="box">
	        <h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">Edit  Students   <span class="teachers"><img src="<?php echo base_url();?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/dashbord');?>" style="color: #a5ce4a;text-decoration: none;">Student List</a></span></h4>
			
			<?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
			<?php  }?> 	
			<?php if( $this->session->flashdata('error') ){ ?>
				<div class="alert alert-danger">
				  <strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
				</div>
			<?php  }?> 
		        <form action="<?php  echo base_url('administration/edit_student?studentid='.$student_id); ?>" id="add_student" method="post" class="middle-forms">
				    <fieldset>      
					   <div id='document_0'>
					  <h3>Edit Student by Fill All fields</h3>				
						<ol id='documentlist_0' style="margin-bottom: 10px;">
							<li class="even">
								<label class="field-title">Student Name<em>*</em>:</label>
								<label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Student Name'" value="<?php  if(set_value('student_name')){echo set_value('student_name');  }  elseif(isset($getstudentdata->student_name)) { echo trim($getstudentdata->student_name); }?>" placeholder="Enter Student Name" id="student_name0" name="student_name" /></label>
							 <span class="error"><?php  echo   form_error('student_name'); ?></span>	
							</li>
					<input type="hidden" name="student_id" value="<?php echo $getstudentdata->student_id; ?>">	
							<li>
								<label class="field-title">fathers Name<em>*</em>:</label>
								<label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Father Name'" value="<?php  if(set_value('std_father_name')){echo set_value('std_father_name');  }  elseif(isset($getstudentdata->std_father_name)) { echo trim($getstudentdata->std_father_name); }?>" placeholder="Enter Father Name" id="std_father_name0" name="std_father_name" /></label>
								 <span class="error"><?php  echo   form_error('std_father_name'); ?></span>
							</li>
							<li class="even">
								<label class="field-title">Gender <em>*</em>: </label> 
								<label><input name="gender" checked="checked" id="gender0" value="male" type="radio"> Male 
								<input name="gender" value="female" id="gender0" type="radio"> Female
								</label><span class="clearFix">&nbsp;</span>
							</li>
							
							<li>
							  <label class="field-title">Mobile No:</label>
							  <label><input class="txtbox-long" type="text"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Mobile no'" value="<?php  if(set_value('student_mobile_no')){echo set_value('student_mobile_no');  }  elseif(isset($getstudentdata->student_mobile_no)) { echo trim($getstudentdata->student_mobile_no); }?>" id="student_mobile_no0" placeholder="Enter Mobile no" name="student_mobile_no" /></label>
							   <span class="error"><?php  echo   form_error('student_mobile_no'); ?></span>
							</li>
							
							<li class="even">
							 <label class="field-title">Email Id<em>*</em>:</label>
							 <label><input class="txtbox-long" type="text"  id="student_email0" onfocus="this.placeholder = ''"  value="<?php  if(set_value('student_email')){echo set_value('student_email');  }  elseif(isset($getstudentdata->student_email)) { echo trim($getstudentdata->student_email); }?>" onblur="this.placeholder = 'Enter Email ID'" placeholder="Enter Email ID" name="student_email" /></label>
							  <span class="error"><?php  echo   form_error('student_email'); ?></span>
							</li>
							<?php  ?>
							<li>
								<label class="field-title">Class<em>*</em>:</label>
								<label>
									<select class="classes_option" id="class0" name="class" style="height: 28px;">
										<option value="" selected>Select Class</option>
									<?php foreach($classlist as $key=>$class) { ?>	
										<option value="<?php echo $class->class_id; ?>"<?php if(set_select('class')){echo set_select('class');  }  elseif($getstudentdata->student_class == $class->class_id) { echo  "selected"; } ?>><?php echo $class->classname;  ?></option>
										<?php  } ?>
									</select>
								</label>
							 <span class="error"><?php  echo   form_error('class'); ?></span>	
							</li>
							
							<li class="even">
							   <label class="field-title">Address<em>*</em>:</label>
							   <label><textarea name="address" id="address0" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" placeholder="Enter Address" rows="3" cols="25"><?php  if(set_value('address')){echo set_value('address');  }  elseif(isset($getstudentdata->address)) { echo trim($getstudentdata->address); }?></textarea></label>
							   <span class="error"><?php  echo   form_error('address'); ?></span> 
							</li>
							
							<li><input type="submit" name="submit" value="Update" class="submit-btn" />
							<a  href="<?php echo base_url('administration/dashbord');?>" class="a-btn">Cancel</a></li>
						</ol>
				        </fieldset>
			        </form>
                </div>            
            </div>            
           <span class="clearFix">&nbsp;</span>     
        </div>
	<style>
	 .error{ color:red; }
		.a-btn {
			background-color: #bbb !important;
			float: right;
			font-size: 17px;
			cursor: pointer;
			padding: 6px;
			border: 1px solid #dedede;
			margin-right: 6px;
			text-decoration: none;
			color: #fff;
		}
	</style>