    <div id="content">
	    <div id="content-top">
         <h2>Add Students</h2>
         <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
          <span class="clearFix">&nbsp;</span>
        </div>        
        <div id="mid-col">
		   
		
	    <div class="box">
	        <h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">Add  Students   <span class="teachers"><img src="<?php echo base_url();?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/dashbord');?>" style="color: #a5ce4a;text-decoration: none;">Student List</a></span></h4>
			
			<?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
			<?php  }?> 	
			<?php if( $this->session->flashdata('error') ){ ?>
				<div class="alert alert-danger">
				  <strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
				</div>
			<?php  }?> 
		    <div class="box-container rounded_by_jQuery_corners add_by_fields">		
			    <form action="<?php  echo base_url('administration/add_student'); ?>" id="add_student" method="post" class="middle-forms">
				<fieldset>      
					<div id='document_0'>
					  <h3>Add Student by Fill All fields</h3>				
						<ol id='documentlist_0' style="margin-bottom: 10px;">
							<li class="even">
								<label class="field-title">Student Name<em>*</em>:</label>
								<label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Student Name'" placeholder="Enter Student Name" id="student_name0" name="student_name[]" /></label>
							</li>
							
							<li>
								<label class="field-title">fathers Name<em>*</em>:</label>
								<label><input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Father Name'" placeholder="Enter Father Name" id="std_father_name0" name="std_father_name[]" /></label>
							</li>
							<li class="even">
								<label class="field-title">Gender <em>*</em>: </label> 
								<label><input name="gender[0]" checked="checked" id="gender0" value="male" type="radio"> Male 
								<input name="gender[0]" value="female" id="gender0" type="radio"> Female
								</label><span class="clearFix">&nbsp;</span>
							</li>
						
							<li>
							  <label class="field-title">Mobile No:</label>
							  <label><input class="txtbox-long" type="text"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Mobile no'" id="student_mobile_no0" placeholder="Enter Mobile no" name="student_mobile_no[]" /></label>
							</li>
							
							<li class="even">
							  <label class="field-title">Email Id<em>*</em>:</label>
							  <label><input class="txtbox-long" type="text"  id="student_email0" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email ID'" placeholder="Enter Email ID" name="student_email[]" /></label>
							</li>
							<?php  //print_r($classlist); ?>
							<li>
								<label class="field-title">Class<em>*</em>:</label>
								<label>
									<select class="classes_option" id="class0" name="class[]" style="height: 28px;">
										<option value="" selected>Select Class</option>
									<?php foreach($classlist as $key=>$class) { ?>	
										<option value="<?php echo $class->class_id;  ?>"><?php echo $class->classname;  ?></option>
										<?php  } ?>
									</select>
								</label>
							</li>
						
							<li class="even">
							   <label class="field-title">Address<em>*</em>:</label>
							   <label><textarea name="address[]" id="address0" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" placeholder="Enter Address" rows="3" cols="25"></textarea></label>
							</li>
							
							<!--<li><<input type="submit" name="submit" value="Submit" class="submit-btn" /></li>-->
						</ol>
				  
							<span>
								<button type="button" id="add_new" class="submit-btn" onclick="studentshow(0);" style="margin: 0px 6px 0px 6px;">Show</button> 
								<button type="button" id="add_new" class="submit-btn"  onclick="studenthide(0);" style="margin: 0px 6px 0px 6px;">Hide</button>
								
								<button type="button" id="add_new" class="submit-btn" onclick="removeaddstudentdiv(0);" style="margin: 0px 6px 0px 6px;">Remove</button>
							</span>	
					</div> 	
					<div class="add_new_document hide"></div>
					<button type="button" id="add_new" class="submit-btn" onclick="addnewsevent();" style="margin-right: 5px;" >Add Student</button>
					<button type="submit" name="submit" id="studentbtn" class="submit-btn"  style="float: left;">submit</button>
				</fieldset>
			    
			    </form>
            </div>     
			
			<div class="Add_from_files">
				<h2>Import CSV File of Student List</h2>
				<form action="<?php  echo base_url('administration/excelfile_student'); ?>"  method="post"  enctype="multipart/form-data" class="middle-forms">
				   <input class="upload_file" type="file" name="file" id="fileupload" onChange="profileimagevalidation(this.value);preview(this);" accept=".csv" />
				  <input type="submit" name="submit" class="submit-btn add_file" value="Submit" />
				</form>		
			</div>
        </div>            
        </div>            
      <span class="clearFix">&nbsp;</span>     
    </div>
		<style>
			 .error{
				 color:red;
			 }
		</style>	
	<script src="https://code.jquery.com/jquery-1.10.2.js"></script>
	<script>
		function removeaddstudentdiv(div_id){
			$('#document_'+div_id).addClass('hide disabled');
			$('#document_'+div_id).html('');
			$('#document_'+div_id+' input').remove();
			$('#document_'+div_id).attr('style','');
		}
		
		function studentshow(div_id){
		   $('#documentlist_'+div_id).show();
		}	
		
		function studenthide(div_id){
			$('#documentlist_'+div_id).hide();
		}	
		
		function addnewsevent()
		{

			$('.add_new_document').removeClass('hide');
			$('.alert-success').hide();	
			var divSize = $(".add_new_document > div").size()+1;
		
		 var divid = divSize - 1;
		 var studentname = $('#student_name'+divid).val();		
		 var stdfathername = $('#std_father_name'+divid).val();		
		 var gender = $('#gender'+divid).val();		
		 var studentmobile_no = $('#student_mobile_no'+divid).val();		
		 var class1 = $('#class'+divid).val();		
		 var address = $('#address'+divid).val();	
			
		 if(studentname == "" || stdfathername == "" || gender == "" || studentmobile_no == "" || class1 == "" || address == ""){
			alert ('Please fill all fields');
					 $('#documentlist_'+divid).show();
					 return false;
		 }	
			
			$.ajax({
					url: '<?php echo base_url(); ?>administration/addnewsevent',
					type: 'POST',
					data: {divSize:divSize},
					success: function(res)
					{
						//alert(res);
						if(divSize=='0'){
							$('.add_new_document').html(res);
						}
						else{
							$('.add_new_document').append(res);
						}
						
					}
			});
		}
		
		$(function() {
			$('button[id="studentbtn"]').on('click', function() {
				$('button[id="studentbtn"]').addClass('disabled');
				resetErrors();
				var url = $('#add_student').attr('action');
				var formData=$('#add_student').serialize();
				$.ajax({
						dataType: 'json',
						type: 'POST',
						url: url,
						data: formData,
						success: function(resp) {
							//console.log(resp);
							
							if(resp.done==='success'){
								
								$('button[id="studentbtn"]').removeClass('disabled');
								window.location.href = "<?php echo base_url('administration/dashbord'); ?>";
								// if(resp.set_submit=='1')
								// {
									//alert(resp.set_submit);
									// // $("#is_submit").val('1');
									// $('#work_order_form').submit();
									// return true;
								// }				
							}else{
								if (resp === true) {
									//successful validation
									$('button[id="studentbtn"]').removeClass('disabled');
									$('#work_order_form').submit();

								} else {
									$('#pageloaddiv').hide();
									$('button[id="studentbtn"]').removeClass('disabled');
									$.each(resp, function(i, v) {
									console.log(i + " => " + v); // view in console for error messages
									var msg = '<label class="error" for="'+i+'">'+v+'</label>';
									$('input[name="' + i + '"],input[id="' + i + '"],select[id="' + i + '"],div[id="' + i + '"],textarea[id="' + i + '"]').addClass('inputTxtError').after(msg);
									});

									var keys = Object.keys(resp);
									$('[name="'+keys[0]+'"]').focus();
								}
							}

						},
						error: function() {
							console.log('there was a problem checking the fields');
						}
					});
					return false;
				});
		});
		
			function resetErrors() {
				$('form input,#vendor_id_chosen,form textarea,div.chosen-container').removeClass('inputTxtError');
				$('label.error').remove();
			}
		
			function profileimagevalidation(file) {
			
						var ext = file.split(".");
						ext = ext[ext.length-1].toLowerCase();      
						var arrayExtensions = ["csv"];

						if (arrayExtensions.lastIndexOf(ext) == -1) {
							alert("Wrong extension type.");
							 $("#fileupload").val("");
						}
						
						/* imgpath=document.getElementById('uploadimage');
					//	alert(imgpath);
						var img=imgpath.files[0].size;
						var imagesize = img/1024;
						if(imagesize > 2048) {
							alert("Your properties image  under 2MB in size");
							 $("#uploadimage").val("");
						} */
				
			}	
		
	</script>	