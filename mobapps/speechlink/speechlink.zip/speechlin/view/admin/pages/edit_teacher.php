    <div id="content">
	    <div id="content-top">
         <h2>Edit Teacher</h2>
         <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a> 
          <span class="clearFix">&nbsp;</span>
        </div>        
        <div id="mid-col">	
	    <div class="box">
	        <h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">Edit Teacher <span class="teachers"><img src="<?php echo base_url();?>files/superadmin/images/plus.png" /><a href="<?php echo base_url('administration/teachers');?>" style="color: #a5ce4a;text-decoration: none;">Teacher List</a></span></h4>
			
	<?php  //print_r($teachelistdata); 
        $teacher_id = base64_encode(base64_encode(base64_encode($teachelistdata->teacher_id))); 
	?>
			<?php if( $this->session->flashdata('message') ){ ?>
				<div class="alert alert-dangers">
				  <strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
				</div>
			<?php  }?> 	
			<?php if( $this->session->flashdata('error') ){ ?>
				<div class="alert alert-danger">
				  <strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
				</div>
			<?php  }?> 
			    <form action="<?php echo base_url('administration/edit_teacher?teacher_id='.$teacher_id); ?>" id="edit_teacher" method="post" class="middle-forms">
					<fieldset> 
						<div id='document_0'>
						   <h3>Edit Teacher by Fill All fields</h3>
							<ol id='documentlist_0' style="margin-bottom: 10px;">
								<li class="even">
									<label class="field-title">Teacher Name<em>*</em>:</label>
									<label>
									  <input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Teacher Name'" value="<?php  if(set_value('teacher_name')){echo set_value('teacher_name');  }  elseif(isset($teachelistdata->teacher_name)) { echo trim($teachelistdata->teacher_name); }?>" placeholder="Enter Teacher Name" id="teacher_name" name="teacher_name" />
									</label>
									<span class="error"><?php  echo   form_error('teacher_name'); ?></span> 
								 </li>
								
							<input type="hidden" name="teacher_id" value="<?php echo $teachelistdata->teacher_id; ?>">	
							
									<!--<li><label class="field-title">lecture<em>*</em>:</label>
									<label>
										<select class="classes_option" style="height: 28px;">
											<option selected>Select lecture&nbsp;</option>
											<option>Mathematics</option>
											<option>Science</option>
											<option>Dance</option>
											<option>Art</option>
											<option>Physical Education</option>
											<option>Basic Math</option>
											<option>Geometry</option>
											<option>Life Science</option>
											<option>Health</option>
											<option>Sports</option>
											<option>Social Science</option>
											<option>English</option>												
										</select>
									</label>
									</li>-->
								<li class="even">
								<label class="field-title">Gender <em>*</em>: </label> 
								<label>
								  <input type="radio" name="gender" checked="checked"  id="gender" value="male"<?php 
                                           echo set_value('male', $teachelistdata->gender) == 'male' ? "checked" : ""; ?>>Male
								  <input  type="radio" name="gender"  id="gender" value="female" <?php 
                                           echo set_value('female', $teachelistdata->gender) == 'female' ? "checked" : ""; ?>>Female
									 
								</label>
								<span class="clearFix">&nbsp;</span>
								</li>
									
								<li>
								  <label class="field-title">Mobile No:</label>
								  <label>
								    <input class="txtbox-long" type="text" onkeyup="integersOnly(this)"  onfocus="this.placeholder = ''"  value="<?php  if(set_value('mobile_number')){echo set_value('mobile_number');  }  elseif(isset($teachelistdata->mobile_number)) { echo trim($teachelistdata->mobile_number); }?>" onblur="this.placeholder = 'Enter Mobile no'" placeholder="Enter Mobile no" name="mobile_number" id="mobile_number"/>
								  </label>
								   <span class="error"><?php  echo   form_error('mobile_number'); ?></span> 	
								</li>
								
								<li class="even">
								  <label class="field-title">Email Id<em>*</em>:</label>
								    <label>
									   <input class="txtbox-long" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email ID'" value="<?php  if(set_value('email')){echo set_value('email');  }  elseif(isset($teachelistdata->email)) { echo trim($teachelistdata->email); }?>" placeholder="Enter Email ID" name="email" id="email" />
									</label>
								     <span class="error"><?php  echo   form_error('email'); ?></span> 	
								</li>
								
								<!--<li><label class="field-title">Assign- Class<em>*</em>:</label>
								<label>
									<select class="classes_option" style="height: 28px;">
										<option selected>Select Class&nbsp;</option>
										<option>Nursery</option>
										<option>LKG</option>
										<option>UKG</option>
										<option>STD I</option>
										<option>STD II</option>
										<option>STD III</option>
										<option>STD IV</option>
										<option>STD V</option>
										<option>STD VI</option>
										<option>STD VII</option>
										<option>STD VIII</option>
										<option>STD IX</option>
										<option>STD X</option>
										<option>STD XI</option>
										<option>STD XII</option>
									</select>
								</label>
								</li>-->
								
								<li class="even">
								   <label class="field-title">Address<em>*</em>:</label>
								      <label>
									    <textarea name="address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" placeholder="Enter Address" rows="3" id="address" cols="25"><?php  if(set_value('address')){echo set_value('address');  }  elseif(isset($teachelistdata->address)) { echo trim($teachelistdata->address); }?></textarea>
									  </label>
									  <span class="error"><?php  echo   form_error('address'); ?></span>  
								</li>
								
								<li>
								    <input type="submit" name="submit" value="Submit" class="submit-btn" />
								<a  href="<?php echo base_url('administration/teachers');?>" class="a-btn">Cancel</a></li>
						    </ol>
				    </fieldset>
			    </form>
            </div>            
        </div>            
      <span class="clearFix">&nbsp;</span>     
    </div>
	    <style>
	 .error{ color:red; }
		.a-btn {
			background-color: #bbb !important;
			float: right;
			font-size: 17px;
			cursor: pointer;
			padding: 6px;
			border: 1px solid #dedede;
			margin-right: 6px;
			text-decoration: none;
			color: #fff;
		}
	</style>
	