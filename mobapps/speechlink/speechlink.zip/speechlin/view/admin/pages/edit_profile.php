<?php // print_r($getuserdetails); ?>
    <div id="content">
	    <div id="content-top">
         <h2>Edit Profile</h2> 
	      <a href="<?php echo base_url('administration/resetpassword');?>" id="topLink">Change Password</a>
           <span class="clearFix">&nbsp;</span>
        </div>      
        <div id="mid-col">   
			<div class="box">
				<h4 class="light-blue rounded_by_jQuery_corners" style="border-top-left-radius: 5px; border-top-right-radius: 5px;">Update Profile</h4>
					<?php if( $this->session->flashdata('message') ){ ?>
						<div class="alert alert-dangers">
						<strong>Successful!</strong> <?php echo $this->session->flashdata('message'); ?>
						</div>
					<?php  } ?> 	
					<?php if( $this->session->flashdata('error') ){ ?>
						<div class="alert alert-danger">
						<strong>Warning!</strong> <?php echo $this->session->flashdata('error'); ?>
						</div>
					<?php  } ?> 
				<form action="" method="post" name="reset" class="reset_form">
					<fieldset>
						<ol>
							<li class="even">
							  <label class="field-title">Name<em>*</em>:</label>
							  <label><input class="txtbox-shorts" type="text" value="<?php if(set_value('name')){echo set_value('name');  }elseif($getuserdetails->user_name != ''){ echo $getuserdetails->user_name;  }?>" name="name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Name'" placeholder="Enter Name"></label>
							   <span class="error"><?php  echo   form_error('name'); ?></span> 
							</li>
							
							
							<li class="even">
							   <label class="field-title">Email Id<em>*</em>:</label>
							   <label><input class="txtbox-shorts" type="text" value="<?php if(set_value('email')){echo set_value('email');  }elseif($getuserdetails->email != ''){ echo $getuserdetails->email; } ?>" name="email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email Id'" placeholder="Enter Email Id" ></label>
							    <span class="error"><?php  echo   form_error('email'); ?></span> 
							</li>
							
							<li class="even">
							  <label class="field-title">Mobile No<em>*</em>:</label> <label><input class="txtbox-shorts" name="mobile" onfocus="this.placeholder = ''" type="text" value="<?php if(set_value('mobile')){echo set_value('mobile');  }elseif($getuserdetails->mobile != '') {echo $getuserdetails->mobile; } ?>" onblur="this.placeholder = 'Enter Mobile No'" placeholder="Enter Mobile No" ></label>
							   <span class="error"><?php  echo   form_error('mobile'); ?></span> 
							</li>
							
							<li class="even">
							  <label class="field-title">Address:</label>
							  <label><textarea name="address"  onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Address'" placeholder="Enter Address" rows="5" cols="45"><?php if(set_value('address')){echo set_value('address');  }elseif($getuserdetails->address != '') {echo $getuserdetails->address; } ?></textarea></label>
							   <span class="error"><?php  echo   form_error('address'); ?></span> 
							</li>
							
							<li class="even"><input type="submit" name="submit" value="Update" class="btns" /></li>			 						
						</ol>
					</fieldset>
				</form>        
			</div>      
        </div>            
        <span class="clearFix">&nbsp;</span>     
    </div>
    </div>
	<style>
	 .error{
		 color:red;
	 }
	</style>