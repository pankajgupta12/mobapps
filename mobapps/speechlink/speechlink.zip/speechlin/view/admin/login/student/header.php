<!DOCTYPE html>
<html idmmzcc-ext-docid="855252992" lang="en-US">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8"> 
	<meta charset="UTF-8">  
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title><?php echo $title; ?></title>
	<link rel="dns-prefetch" href="http://fonts.googleapis.com/">
	<link rel="stylesheet" href="<?php echo base_url();?>files/student/css/style.css" type="text/css" media="all">
	<script src="<?php echo base_url();?>files/student/js/jquery.min.js"></script>
</head>
<body>	
	<div id="container">	
		<div id="main_content">
			<div class="box_header">
				<div class="left_box_header">
					<a href="<?php echo base_url('student/student_dashbord');?>"><img src="<?php echo base_url();?>files/student/images/logo.png" width="150px" alt="logo" /></a>
				</div>
				<div class="right_box_header">
					<span>Welcome: <?php  if($_SESSION['student_name'] != '') { echo ucfirst($_SESSION['student_name']);  } ?></span>
					<ul>				
						<li><a href="<?php echo base_url('student/logout');  ?>">Logout</a></li>
						<li><a href="#">Edit Profile</a></li>
						
					</ul>
				</div>
			</div>
			