<div class="footer-container">
			<div class="footer"><p>Copyright © 2016 School.All Rights Reserved.</p></div>
		</div>
	</div>

</body>
</html>	