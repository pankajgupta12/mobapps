<?php // print_r($_SESSION); ?>

<div class="box">
				<div class="left_box">
					<h2>Student</h2>
					<h2>ABC University</h2>
					<!--<span>Inbox (2)</span>-->
					<ul class="first-child">
						<li class="active"><a href="#">BIO2010</a>
							<ul class="second-child">
								<li class="actives"><a href="#">10/05/2016</a></li>
								<li><a href="#">10/06/2016</a></li>
								<li><a href="#">10/07/2016</a></li>
							</ul>
						</li>
						<li><a href="#">BIO2020</a></li>
						<li><a href="#">BIO2030</a></li>
						<li><a href="#">BIO2040</a></li>
						<li><a href="#">BIO2050</a></li>
						<li><a href="#">BIO2060</a></li>
						<li><a href="#">BIO2070</a></li>
					</ul>
				</div>
				<div class="middle_box">
					<div class="boxes">
						<h3>BIO2010</h3>
						<strong>Streaming 10/05/2016</strong>
						<!--<textarea id="txtArea" rows="14" cols="45" placeholder="text...."></textarea>-->Descriptive writing creates an impression in the reader’s mind of an event, a place, a person, or thing. The writing will be such that it will set a mood or describe something in such detail that if the reader saw it, they would recognize it. Descriptive writing will bring words to life and makes the text interesting. Descriptive writing creates an impression in the reader’s mind of an event, a place, a person, or thing. The writing will be such that it will set a mood or describe something in such detail that if the reader saw it, they would recognize it. Descriptive writing will bring words to life and makes the text interesting. Descriptive writing creates an impression in the reader’s mind of an event, a place, a person, or thing. The writing will be such that it will set a mood or describe something in such detail that if the reader saw it, they would recognize it. Descriptive writing will bring words to life and makes the text interesting. 					
					</div>
				</div>
				<div class="right_box">
					<div class="boxes">
						<h3>BIO2010</h3>
						<strong>Notes 10/05/2016</strong>	
						<ul class="document_list">
							<li><a href="<?php echo base_url();?>files/student/pdf/BIO2010-10052016.pdf" target="black">BIO2010-10/05/2016.pdf</a></li>
							<li><a href="<?php echo base_url();?>files/student/pdf/BIO2010-10052016.pdf" target="black">BIO2010-10/06/2016.pdf</a></li>
							<li><a href="<?php echo base_url();?>files/student/pdf/BIO2010-10052016.pdf" target="black">BIO2010-10/07/2016.pdf</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>	