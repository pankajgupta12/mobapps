        <div class="box">
				<div class="left_box">
					<h2>Teacher</h2>
					<h2>ABC University</h2>
					<!--<span>Inbox (2)</span>-->
					<ul class="first-child">
						<li class="active"><a href="#">BIO2010</a>
							<ul class="second-child">
								<li class="actives"><a href="#">10/05/2016</a></li>
								<li><a href="#">10/06/2016</a></li>
								<li><a href="#">10/07/2016</a></li>
							</ul>
						</li>
						<li><a href="#">BIO2020</a></li>
						<li><a href="#">BIO2030</a></li>
						<li><a href="#">BIO2040</a></li>
						<li><a href="#">BIO2050</a></li>
						<li><a href="#">BIO2060</a></li>
						<li><a href="#">BIO2070</a></li>
					</ul>
				</div>
				<div class="middle_box">
					<div class="boxes">
						<h3>BIO2010</h3>
						<strong>Streaming 10/05/2016</strong>
						<textarea id="txtArea" rows="14" cols="45" placeholder="text...."></textarea>
						<div class="icons">
							<ul>
								<li><button id="saveRecognition"><img src="<?php echo base_url();?>files/student/images/save.png" alt="save" /></button></li>
								<li><button id="startRecognition"><img src="<?php echo base_url();?>files/student/images/play.png" alt="play" /></button></li>
								<li><button id="pauseRecognition"><img src="<?php echo base_url();?>files/student/images/pause.png" alt="pause" /></button></li>
								<li><button id="stopRecognition"><img src="<?php echo base_url();?>files/student/images/stop.png" alt="stop" /></button></li>
								<li><button id="cancelRecognition"><img src="<?php echo base_url();?>files/student/images/cancel.png" alt="cancel" /></button></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="right_box">
					<div class="boxes">
						<h3>BIO2010</h3>
						<strong>Notes 10/05/2016</strong>	
						<ul class="document_list">
							<li><a href="<?php echo base_url();?>files/student/pdf/BIO2010-10052016.pdf" target="black">BIO2010-10/05/2016.pdf</a></li>
							<li><a href="<?php echo base_url();?>files/student/pdf/BIO2010-10052016.pdf" target="black">BIO2010-10/06/2016.pdf</a></li>
							<li><a href="<?php echo base_url();?>files/student/pdf/BIO2010-10052016.pdf" target="black">BIO2010-10/07/2016.pdf</a></li>
						</ul>
						<div class="iconss">
							<ul>
								<li><label id="saveRecognition" for="file"><img src="<?php echo base_url();?>files/student/images/files-folders.png" alt="save" /></label></li>		
								<input type="file" name="music" id="file" style="display:none;" />
						</ul>
					</div>
				</div>
			</div>
		</div>
	<script type = "text/javascript">
	$(function () {
	  try {
		var recognition = new webkitSpeechRecognition();
	  } catch (e) {
		var recognition = Object;
	  }
	  recognition.continuous = true;
	  recognition.interimResults = true;
	  recognition.onresult = function (event) {
		var txtRec = '';
		for (var i = event.resultIndex; i < event.results.length; ++i) {
		  txtRec += event.results[i][0].transcript;
		}
		$('#txtArea').val(txtRec);
	  };
	  $('#startRecognition').click(function () {
		$('#txtArea').focus();
		recognition.start();
	  });
	  $('#stopRecognition').click(function () {
		recognition.stop();
	  });
	});
	</script>