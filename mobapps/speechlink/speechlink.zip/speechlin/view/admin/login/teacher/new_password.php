
<div class="container">
  <div class="info">
    <h1>Password reset for Teacher </h1></span>
  </div>
</div>
<?php 

	if(isset($_GET['rdcd'])){
		$rand = $_GET['rdcd'];
	}
	
	if(isset($_GET['id'])){
		$email = $_GET['id'];
	}
		//isset($_GET['id'];
		
 ?>
    <div class="form">
       <div class="thumbnail"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/169963/hat.svg"/></div>
	   <span id="msg_show" style="display:none;color:green">Reset Password For Teacher</span>
		<form class="login-form" action="<?php echo base_url('teacher/new_password?rdcd='.$rand.'&id='.$email); ?>" id="new_password" method="post">
			
			<input type="password" name="password" placeholder="Password"/>
			<span class="eroor"><?php echo form_error('password');  ?></span>
			
			<input type="password" name="confirm_password" placeholder="Confirm password"/>
			<span class="eroor"><?php echo form_error('confirm_password');  ?></span>
			
			 <button id="login">Reset Password</button></br>
		</form>
		  
    </div>
	<style>
	  .eroor{
		  color:red;
	  }
	</style>