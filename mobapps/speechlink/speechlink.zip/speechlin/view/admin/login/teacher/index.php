
<div class="container">
  <div class="info">
    <h1>Teacher Login</h1></span>
  </div>
</div>
    <div class="form">
       <div class="thumbnail"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/169963/hat.svg"/></div>
	    
	    <form class="register-form" method="post" id="singup"> 
			<!--<input type="text" name="user_name" placeholder="User name" id="user_name"/>-->
				 
			<input type="email" name="email"  id="email" placeholder="Plese enter email address"/>
				
			<!--<input type="password"  name="password"  id="password" placeholder="Password"/>
				 
			<input type="password" name="conf_password" id="conf_password" placeholder="Confirm password"/>-->
			
		   <button id="singup">Submit</button>
		   <p class="message"><a >Sign In</a></p>
	    </form>
	
		<form class="login-form" action="<?php echo base_url('teacher/login'); ?>" id="login" method="post">
		
		  <?php if( $this->session->flashdata('error') ){ ?>
				<div style="color: red;">
				  <?php echo $this->session->flashdata('error'); ?>
				</div>
				</br>
			<?php  }?> 
			
			<input type="text" name="teacher_loginname"  placeholder="User name"/>
			<span class="eroor"><?php echo form_error('teacher_loginname');  ?></span>
			
			<input type="password" name="teacher_password" placeholder="Password"/>
			<span class="eroor"><?php echo form_error('teacher_password');  ?></span>
			
			 <button id="login">login</button></br>
			
			<p class="message"> <a >Forget Password</a></p>
		</form>
		  
    </div>
	<style>
	  .eroor{
		  color:red;
	  }
	</style>
	