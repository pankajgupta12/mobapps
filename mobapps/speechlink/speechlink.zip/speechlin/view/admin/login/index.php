
<div class="container">
  <div class="info">
    <h1>Superadmin Login</h1></span>
  </div>
</div>
    <div class="form">
       <div class="thumbnail"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/169963/hat.svg"/></div>
	   <span id="msg_show" style="display:none;color:green">Your Registration is successfully</span>
	    <form class="register-form" method="post" id="singup"> 
			<!--<input type="text" name="user_name" placeholder="User name" id="user_name"/>-->
				 
			<input type="email" name="email"  id="email" placeholder="Plese enter email address"/>
				
			<!--<input type="password"  name="password"  id="password" placeholder="Password"/>
				 
			<input type="password" name="conf_password" id="conf_password" placeholder="Confirm password"/>-->
			
		   <button id="singup">Submit</button>
		   <p class="message"><a >Sign In</a></p>
	    </form>
	
		<form class="login-form" action="<?php echo base_url('administration/login'); ?>" id="login" method="post">
			<input type="text" name="user_loginname"  placeholder="User name"/>
			<span class="eroor"><?php echo form_error('user_loginname');  ?></span>
			
			<input type="password" name="user_password" placeholder="Password"/>
			<span class="eroor"><?php echo form_error('user_password');  ?></span>
			
			 <button id="login">login</button></br>
			
			<p class="message"> <a >Forget Password</a></p>
		</form>
		  
    </div>
	<style>
	  .eroor{
		  color:red;
	  }
	</style>
	<script>
	
	
	     var data = {};
			$(document).ready(function() {
			$('button[id="singup"]').on('click', function() {
			//alert('sjhas');
			 resetErrors();
			  var url = '<?php echo base_url(); ?>administration/singup';
			var formData=$('#singup').serialize();
			$.ajax({
			dataType: 'json',
			type: 'POST',
			url: url,
			data: formData,
			success: function(resp) {
			  if(resp.done==='success'){
				   $('#singup')[0].reset();
				   $('#msg_show').show();
				   $('#msg_show').fadeOut(3000);
			  } else {
				 // alert(resp);
				  $.each(resp, function(i, v) {
				  console.log(i + " => " + v); // view in console for error messages
					  var msg = '<label class="error" style="color:red" for="'+i+'">'+v+'</label>';
					  $('input[id="' + i + '"],input[name="' + i + '"], select[name="' + i + '"],select[id="' + i + '"]').addClass('inputTxtError').after(msg);
				  });
				  var keys = Object.keys(resp);
				  $('input[name="'+keys[0]+'"]').focus();
			  }
			  return false;
			},
			error: function() {
			  console.log('there was a problem checking the fields');
			}
			});
			return false;
			});
			});
			
			/*  var data = {};
			$(document).ready(function() {
			$('button[id="login"]').on('click', function() {
			//alert('sjhas');
			 resetErrors();
			  var url = '<?php echo base_url(); ?>administration/login';
			var formData=$('#login').serialize();
			$.ajax({
			dataType: 'json',
			type: 'POST',
			url: url,
			data: formData,
			success: function(resp) {
			  if(resp.done==='success'){
				
			  } else {
				 // alert(resp);
				  $.each(resp, function(i, v) {
				  console.log(i + " => " + v); // view in console for error messages
					  var msg = '<label class="error" style="color:red" for="'+i+'">'+v+'</label>';
					  $('input[id="' + i + '"],input[name="' + i + '"], select[name="' + i + '"],select[id="' + i + '"]').addClass('inputTxtError').after(msg);
				  });
				  var keys = Object.keys(resp);
				  $('input[name="'+keys[0]+'"]').focus();
			  }
			  return false;
			},
			error: function() {
			  console.log('there was a problem checking the fields');
			}
			});
			return false;
			});
			}); */
			
		function resetErrors() {
			$('form input, form select').removeClass('inputTxtError');
			$('label.error').remove();
		}
		
	  function showadmintype(){
		   window.location.href = '<?php echo base_url('administration/admin_type'); ?>'
	  }	
	</script>