
<div class="container">
  <div class="info">
    <h1>Admin Type</h1></span>
  </div>
</div>
    <div class="form">
       <div class="thumbnail"><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/169963/hat.svg"/></div>
	   <span id="msg_show" style="display:none;color:green">Your Registration is successfully</span>
	   
	     <form method="post" action="">
			 <select name="admin_type" Onchange="selectAdminType(this.value);">
			    <option value="">Select admin Type</option>
			    <option value="1">Superadmin</option>
			    <option value="2">Teacher</option>
			    <option value="3">Student</option>
			 </select>
		</form>	
		
    </div>
	<style>
	  .eroor{
		  color:red;
	  }
	  form select {
    outline: 0;
    background: #f2f2f2;
    width: 100%;
    border: 0;
    margin: 0 0 15px;
    padding: 15px;
    border-top-left-radius: 3px;
    border-top-right-radius: 3px;
    border-bottom-left-radius: 3px;
    border-bottom-right-radius: 3px;
    box-sizing: border-box;
    font-size: 14px;
}
	</style>
	<script>
	     function selectAdminType(id){
			  if(id == '1'){
				 window.location.href = '<?php echo base_url('administration/superadmin'); ?>';
			 }else if(id == '2'){
				 window.location.href = '<?php echo base_url('administration/teacher'); ?>';
			 }else if(id == '3'){
				 window.location.href = '<?php echo base_url('administration/student'); ?>';
			 } 
			 
		 }
		
	</script>