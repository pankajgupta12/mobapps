<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

		
	  	public function index()
		{
			
			$data =array();
			$data['title']  ='Home page';
			$this->load->view('pages/header', $data);
			$this->load->view('pages/index', $data);
			$this->load->view('pages/footer', $data);
			
		} 
	
		public function about()
		{
			
			$data =array();
			$data['title']  ='About us';
			$this->load->view('pages/header', $data);
			$this->load->view('pages/about', $data);
			$this->load->view('pages/footer', $data);
			
		} 
			public function contact()
		{
			
			$data =array();
			$data['title']  ='Contact';
			$this->load->view('pages/header', $data);
			$this->load->view('pages/contact', $data);
			$this->load->view('pages/footer', $data);
			
		} 
		
    }
