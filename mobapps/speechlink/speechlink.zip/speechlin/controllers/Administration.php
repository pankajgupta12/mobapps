<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Administration extends CI_Controller {

       function __Construct(){
        parent::__Construct();
			$this->load->model('base_model');
			$this->load->helper(array('form', 'url','superadmin'));
			//$this->load->helper('download');
			$this->load->library('Excel_reader');
			//$this->load->library('session');
			date_default_timezone_set("Asia/Kolkata");
             
        }
		
	  	public function index()
		{
			
			$data =array();
			$data['title']  ='Superadmin Login';
			$this->load->view('admin/login/header', $data);
			$this->load->view('admin/login/index', $data);
			$this->load->view('admin/login/footer', $data);
			
		} 
		
		/* public  function superadmin(){
			$data =array();
			$data['title']  ='Home page';
			$this->load->view('admin/login/header', $data);
			$this->load->view('admin/login/index', $data);
			$this->load->view('admin/login/footer', $data);
			
		} */
		
		
		
 		 	 
		public function login(){
			
			 $this->form_validation->set_rules('user_loginname', 'Email', 'trim|required|valid_email');
			 $this->form_validation->set_rules('user_password', 'Password', 'trim|required');
			
			 if ($this->form_validation->run() == TRUE)
				{
					
					 	 if($this->input->post() !='')
					    {
					          $email =  $this->input->post('user_loginname');
						      $password =  md5($this->input->post('user_password'));
							  
							$this->db->select('*');
							$this->db->from('tbl_registration');
							$this->db->where('email',$email);
							$this->db->where('password',$password);  
							$query = $this->db->get();
						 //	echo $this->db->last_query(); die;
							if($query->num_rows() == 1)
							{
								$data = array();
								$row=$query->row();
								
										$data=array(
										'user_id'=>$row->user_id,
										'email'=>$row->email,
										'user_name'=>$row->user_name,
										'logout_time'=>$row->logout_time
										);
										
								$this->session->set_userdata($data);           
							    redirect(base_url('administration/dashbord'));
							}
							else
							{
							  $this->session->set_flashdata('message', 'Your email and password is wrong.');
							} 
					    } 
				}	   
		    $data['title'] = "Superadmin Login";
			$this->load->view('admin/login/header',$data);
			$this->load->view('admin/login/index');
			$this->load->view('admin/login/footer');
		}
			
		function logout()
		{
			//$userID = $this->session->userdata('user_id');
			$this->db->where('user_id',$this->session->userdata('user_id'));
			//$updatedata = ;
			$this->db->update('tbl_registration',array('logout_time'=>date("Y-m-d h:i:s")));
			
			 /* $newdata = array(
						'user_id'  =>'',
						'email' => '',
						'user_name' => '',
						'logged_in' => FALSE,
					   ); 
					   
			$this->session->unset_userdata($newdata);
			$this->session->sess_destroy(); */
			unset($_SESSION['user_id']);
			unset($_SESSION['email']);
			unset($_SESSION['user_name']);
			unset($_SESSION['logout_time']);

			redirect(base_url('administration/login'));
		}
		
        public function login_check()
		{
				if($this->session->userdata('user_id') == "" && $this->session->userdata('email') =="") { 
					  redirect(base_url('administration/login'));
				}
		}
			
		public function singup(){
		
		        $errors = array();
		        $data = array();
				
				if(empty($_POST['user_name'])){
						$errors['user_name'] = 'Enter user name';				
				}	
						
					if(empty($_POST['email'])){
							$errors['email'] = 'Enter email';				
						}elseif(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
							  $errors['email'] = "Invalid email"; 
							}else{
							$resultdata = $this->db->get_Where('tbl_registration', array('email'=>$_POST['email']))->row();
							if($resultdata){
								$errors['email'] = 'email id already exist';	
							}
						}
					
					if(empty($_POST['password'])){
							$errors['password'] = 'Enter password';				
						}
						
					if(empty($_POST['conf_password'])){
							$errors['conf_password'] = 'Enter confirm password';				
						}
						
					if($_POST['password'] != $_POST['conf_password']){
						 $errors['conf_password'] = 'confirm password did not match';	
				    }		
					
				if(count($errors) > 0){
				//This is for ajax requests:
					if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
						echo json_encode($errors);
						exit;
					 }
				//This is when Javascript is turned off:
						   echo "<ul>";
						   foreach($errors as $key => $value){
						  echo "<li>" . $value . "</li>";
						   }
			 			   echo "</ul>";exit;
		        }else{
							
						$user_name =  $this->input->post('user_name');
						$email =  $this->input->post('email');
						$password =  $this->input->post('password');
						$created_at     = date("Y-m-d h:i:s");
					    
						$insertData = 
						       array(
									 'user_name'=>$user_name,
									 'email'=>$email,
									 'password'=>md5($password),
									 'created_at'=>$created_at
							        );
					  $this->db->insert('tbl_registration', $insertData);
					  
				    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
						$errors['done']='success';
						//$errors['MSG']='Work order has been added successfully.';
						echo json_encode($errors);
						//redirect('masterForm/raw_material_master');
						exit;
				    }
				}
		}
		
		public function dashbord(){
			//print_r($_POST); 
			
			$this->login_check();
			$data = array();
			
				$this->db->select('*');
				$this->db->from('tbl_student');
				$this->db->order_by("student_id", "desc");
				$query = $this->db->get(); 
				$data['studentlist'] = $query->result();
		    //$data['studentlist'] = $this->db->get('tbl_student')->order_by('student_id','desc')->result();
			
			$data['title'] = "Student";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/dashbord');
			$this->load->view('admin/pages/footer');
			
		}
		public function add_student(){
			
			 //	echo "<pre>";  print_r($_POST);  die;
			$this->login_check(); 
			$data = array();
			//$data['classlist'] = array('0'=>'Nursery','1'=>'LKG','2'=>'UKG','3'=>'STD I','4'=>'STD II','5'=>'STD III','6'=>'STD IV','7'=>'STD V','8'=>'STD VI','9'=>'STD VII','10'=>'STD VIII','11'=>'STD IX','12'=>'STD X','13'=>'STD XI','14'=>'STD XII');
			    $data['classlist'] =  $this->db->get('tbl_class')->result();
			 
			 $errors = array();
		     
					if($_POST)	 {
						foreach($_POST['std_father_name'] as $key=>$val) {
								if(empty($_POST['student_name'][$key])){
										$errors['student_name'.$key] = 'Enter student name';				
								}	
									
								if(empty($_POST['std_father_name'][$key])){
										$errors['std_father_name'.$key] = 'Enter  student father name';				
									}
									
								if(empty($_POST['student_mobile_no'][$key])){
										$errors['student_mobile_no'.$key] = 'Enter student mobile number';				
								}elseif(strlen($_POST['student_mobile_no'][$key]) != 10){
									$errors['student_mobile_no'.$key] = 'Plese enter  mobile number 10 digit';	
								}
								
								$resultdata = $this->db->get_Where('tbl_student', array('student_email'=>$_POST['student_email'][$key]))->row();	
								if(!empty($resultdata)){
											$errors['student_email'.$key] = 'Email id already exist';	
								}else{
								if(empty($_POST['student_email'][$key])){
										$errors['student_email'.$key] = 'Enter email';				
									}elseif(!filter_var($_POST['student_email'][$key], FILTER_VALIDATE_EMAIL)) {
										  $errors['student_email'.$key] = "Invalid email"; 
									}
								}
									
								if($_POST['class'][$key] == ""){
									 $errors['class'.$key] = 'Select class';	
								}
							   
								if(empty($_POST['address'][$key])){
									 $errors['address'.$key] = 'Enter address';	
								}
						}		
								  $dupes = array_diff_key( $_POST['student_email'], array_unique($_POST['student_email'])); 	
								   if(!empty($dupes)) { 				  
									  foreach($dupes as $value=>$dupvalue){
										 $errors['student_email'.$value] = "Duplicate invalid email"; 
									 }  	
									}					 
							//echo "<pre>";  print_R($errors); die;	
							if(count($errors) > 0){
							//This is for ajax requests:
								if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
									echo json_encode($errors);
									exit;
								 }
							//This is when Javascript is turned off:
							//print_r($errors);
									   echo "<ul>";
									   foreach($errors as $key => $value){
									  echo "<li>" . $value . "</li>";
									   }
									   echo "</ul>";exit;
							}else{
								
								foreach($_POST['std_father_name'] as $key=>$val) {
									
									$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
									$pass = array(); //remember to declare $pass as an array
									$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
									for ($i = 0; $i < 8; $i++) {
										$n = rand(0, $alphaLength);
										$pass[] = $alphabet[$n];
									}
									
									
										 $student_name = $_POST['student_name'][$key];
										 $std_father_name = $_POST['std_father_name'][$key];
										 $student_mobile_no = $_POST['student_mobile_no'][$key];
										 $student_email = $_POST['student_email'][$key];
										 $gender = $_POST['gender'][$key];
										 $class = $_POST['class'][$key];
										 $address = $_POST['address'][$key];
										 $rand_number = implode($pass);
										 $created_at  = date("Y-m-d h:i:s");

													$insertData =  array(
																 'student_name'=>$student_name,
																 'std_father_name'=>$std_father_name,
																 'student_mobile_no'=>$student_mobile_no,
																 'student_email'=>$student_email,
																 'gender'=>$gender,
																 'student_class'=>$class,
																 'rand_number'=>$rand_number,
																 'address'=>$address,
																 'crated_at'=>$created_at
																);	

										$from_email = "speechtotext@gmail.com"; 
									//$to = "pankajmobapps@gma"; 
									//$rand_number = $userdata->rand_number; 
									//$getemail = $userdata->email; 
									$getemailid = base64_encode($student_email); 

									//$to_email = $email; 
					$link = "http://mobileandwebsitedevelopment.com/speechlinklive/student/new_password?rdcd=".$rand_number.'&id='.$getemailid;
									//Load email library 
									//$clicklink  ="<a href='$link'>Click Here</a>";
									$name  = ucfirst($student_name);

									/* $mesg  = "Hello " . $name;
									$mesg .= "<BR>";
									$mesg .= "Click on this link to reset your password .";
									$mesg .= "Reset Password ".$clicklink; */


									$mesg  = "Hello " . $name."\n";							
									$mesg .= "You Have added as Student and Invited of Speech link.\n";
									$mesg .= "Please Reset Password click \n"; 
									$mesg .= $link; 


									$this->load->library('email'); 

									$this->email->from($from_email); 
									$this->email->to($student_email);
									$this->email->subject('You have Invited speech link'); 
									$this->email->message($mesg); 
									$this->email->send();													
									$this->db->insert('tbl_student', $insertData);
								}		
								  
								if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
									$errors['done']='success';
									//$errors['MSG']='Work order has been added successfully.';
									echo json_encode($errors);
									//redirect('masterForm/raw_material_master');
									exit;
								}
								
								
							}  
						  
						  
					}	  
			  
			$data['title'] = "Student";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/add_student');
			$this->load->view('admin/pages/footer');
		}
		
		public function delete_student(){
			
			if(isset($_GET['studentid'])){
			$studentid = base64_decode(base64_decode(base64_decode($_GET['studentid']))); 
			//$this->db->where('student_id',$studentid);
			 $this->db->delete('tbl_student',array('student_id'=>$studentid));
			 $this->session->set_flashdata('message', 'One row delete successfully');
			 redirect(base_url('administration/dashbord'));
			}
		} 
		
		
			public function addnewsevent()
		{
			 $data = array();
			
			$data['classlist'] = $this->db->get('tbl_class')->result();
			$data['divsize']=$_POST['divSize'];
			$this->load->view('admin/includes/addnewstudent',$data);
		}
        
        function excelfile_student()
		{
			
			if(isset($_POST["submit"])){
				
             if($_FILES['file']['name'] != "") {				
				$filename = $_FILES['file']['tmp_name'];
				$file_check = $_FILES['file']['name'];

				 if($_FILES["file"]["size"] > 0)
				{
						 //if ($file_check != ""){
						/*  $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
								 $expensions= array("csv");
								 if(in_array($file_ext,$expensions)){ */
						  $file = fopen($filename, "r");
						  $c = 0;
						  $d = 0;
						  $valid_e = 0;
				while (($emapData = fgetcsv($file, 10000, ",")) != FALSE) {	  
					  if(filter_var($emapData[2], FILTER_VALIDATE_EMAIL)) {
						  
						$checkemailexit = $this->db->get_Where('tbl_student',array('student_email'=>$emapData[2]))->row();  
 						 
						if(empty($checkemailexit)) {
							
                        			
									$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
									$pass = array(); //remember to declare $pass as an array
									$alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
									for ($i = 0; $i < 8; $i++) {
										$n = rand(0, $alphaLength);
										$pass[] = $alphabet[$n];
									}


						
						   $created_at     = date("Y-m-d h:i:s");
						    $rand_number = implode($pass);
							$insertData =  array(
										'student_name'=>$emapData[0],
										'std_father_name'=>$emapData[1],
										'student_email'=>$emapData[2],
										'student_mobile_no'=>$emapData[3],
										'student_class'=>$emapData[4],
										'address'=>$emapData[5],
										'gender'=>$emapData[6],
										'rand_number'=>$rand_number,
										'crated_at'=>$created_at
										);
										
								$c = $c + 1;
								
								
							$from_email = "speechtotext@gmail.com"; 
							//$to = "pankajmobapps@gma"; 
							//$rand_number = $userdata->rand_number; 
							//$getemail = $userdata->email; 
							$getemailid = base64_encode($emapData[2]); 
 
							//$to_email = $email; 
							$link = "http://mobileandwebsitedevelopment.com/speechlinklive/student/new_password?rdcd=".$rand_number.'&id='.$getemailid;
							//Load email library 
							//$clicklink  ="<a href='$link'>Click Here</a>";
							$name  = ucfirst($emapData[0]);

							/* $mesg  = "Hello " . $name;
							$mesg .= "<BR>";
							$mesg .= "Click on this link to reset your password .";
							$mesg .= "Reset Password ".$clicklink; */


							$mesg  = "Hello " . $name."\n";							
							$mesg .= "You Have added as Student and Invited of Speech link.\n";
							$mesg .= "Reset Password click "; 
							$mesg .= $link; 


							$this->load->library('email'); 

							$this->email->from($from_email); 
							$this->email->to($emapData[2]);
							$this->email->subject('You have Invited speech link'); 
							$this->email->message($mesg); 
							$this->email->send();
							$this->db->insert('tbl_student', $insertData);	
							}else{
							  $d = $d + 1;
							  continue;
							}
						}
					}
					fclose($file);
					$this->session->set_flashdata('message', "You database has imported successfully. You have inserted $c recoreds and duplicate email and invalid email is $d ");
					redirect(base_url('administration/add_student'));				 
				}}else{
					 $this->session->set_flashdata('error', 'Please Select File.');
					 redirect(base_url('administration/add_student'));
				}	
		    }	
		    
		    $data['title'] = "Student";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/add_student');
			$this->load->view('admin/pages/footer');	
		  	
		}	

        public function edit_student(){
			
			$data = array();
		     
			 
			if(isset($_GET['studentid'])){
				$studentid = base64_decode(base64_decode(base64_decode($_GET['studentid']))); 
				
				$data['getstudentdata'] = $this->db->get_where('tbl_student',array('student_id'=>$studentid))->row();
				
			}
			 $this->form_validation->set_rules('student_name', 'student name', 'trim|required');
			 $this->form_validation->set_rules('std_father_name', 'student father name', 'trim|required');
			// $this->form_validation->set_rules('gender', 'gender', 'trim|required');
			 $this->form_validation->set_rules('student_mobile_no', 'mobile number', 'trim|required');
			 $this->form_validation->set_rules('student_email', 'email', 'trim|required');
			 $this->form_validation->set_rules('class', 'class', 'trim|required');
			 $this->form_validation->set_rules('address', 'address', 'trim|required');
			
			 if ($this->form_validation->run() == TRUE)
				{
					
					 	 if($this->input->post() !='')
					    {
					          $student_id =  $this->input->post('student_id');
					          $student_name =  $this->input->post('student_name');
					          $std_father_name =  $this->input->post('std_father_name');
					          $gender =  $this->input->post('gender');
					          $student_mobile_no =  $this->input->post('student_mobile_no');
					          $student_email =  $this->input->post('student_email');
					          $class =  $this->input->post('class');
					          $address =  $this->input->post('address');
							  
							    $updatedata = array(
										'student_name'=>$student_name,
										'std_father_name'=>$std_father_name,
										'student_mobile_no'=>$student_mobile_no,
										'student_email'=>$student_email,
										 'gender'=>$gender,
										'student_class'=>$class,
										'address'=>$address
  							        );
						$this->db->where('student_id',$studentid);
                        $this->db->update('tbl_student',$updatedata);
						$this->session->set_flashdata('update_message', "One student has been update successfully");	
							redirect(base_url('administration/dashbord')); 
						}
				}
			//$data['classlist'] = array('0'=>'Nursery','1'=>'LKG','2'=>'UKG','3'=>'STD I','4'=>'STD II','5'=>'STD III','6'=>'STD IV','7'=>'STD V','8'=>'STD VI','9'=>'STD VII','10'=>'STD VIII','11'=>'STD IX','12'=>'STD X','13'=>'STD XI','14'=>'STD XII');
			
			    $data['classlist'] =  $this->db->get('tbl_class')->result();
			
			$data['title'] = "Edit Student";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/edit_student',$data);
			$this->load->view('admin/pages/footer');
		}
		
		public function teachers(){
			$this->login_check();
			$data = array();
			
			$this->db->select('*');
			$this->db->from('tbl_teacher');
			$this->db->order_by("teacher_id", "desc");
			$query = $this->db->get(); 
			$data['teacherlist'] = $query->result();
			
			$data['title'] = "Teachers List";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/teachers',$data);
			$this->load->view('admin/pages/footer');
		}
		
		
		
		
		public function lecture(){
			$this->login_check();
			//print_r($_SESSION);
			$data = array();
			$data['title'] = "Lecture";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/lecture');
			$this->load->view('admin/pages/footer');
		}
		
		public function classes(){
			$this->login_check();
			$data = array();
			$data['title'] = "Classes";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/classes');
			$this->load->view('admin/pages/footer');
		}
		
		public function edit_profile(){
			$this->login_check();
			$data = array();
			$user_id = $this->session->userdata('user_id');
			$user_id = $this->session->userdata('user_id');
			$data['getuserdetails'] = $this->db->get_where('tbl_registration',array('user_id'=>$user_id))->row();
			
			
			$this->form_validation->set_rules('name', 'Name', 'trim|required');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|callback_check_email['.$user_id.']');
			$this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|regex_match[/^[0-9]{10}$/]');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			
			 if ($this->form_validation->run() == TRUE)
				{
					
						 if($this->input->post() !='')
					    {
							//  $user_id =  $this->input->post('user_id');
							  $name =  $this->input->post('name');
							  $email =  $this->input->post('email');
							  $mobile =  $this->input->post('mobile'); 
							  $address =  $this->input->post('address'); 
							  $table = 'tbl_registration';
							  
							  $updateData = array(
											  'user_name'=>$name,
											  'email'=>$email,
											  'mobile'=>$mobile,
											  'address'=>$address
											);
						$where = array('user_id'=>$user_id);		 
						$updatequery  = $this->base_model->update_record_by_id($table,$updateData,$where);	
						 if($updatequery){
								 $this->session->set_flashdata('message', 'Your profile is updated successfully');
							     redirect(base_url('administration/edit_profile'));
							}else{
								$this->session->set_flashdata('error', 'Your profile is not update');
							     redirect(base_url('administration/edit_profile'));
							}
							
						}
				}
			
			$data['title'] = "Edit Profile";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/edit_profile',$data);
			$this->load->view('admin/pages/footer');
		}
			public function check_email($email,$user_id)
		{
			$userdata = $this->db->get_where('tbl_registration',array('email'=>$email,'user_id !='=>$user_id))->row();
			
			if ($userdata)
            {
				$this->form_validation->set_message('check_email', 'The  %s email id already exist.');
				return FALSE;
			}
			else
			{
				return TRUE;
			} 
		}
		
        public function resetpassword(){
			$this->login_check();
			$data = array();
			
            $this->form_validation->set_rules('old_password', 'Password', 'trim|required');
			$this->form_validation->set_rules('new_password', 'New Password', 'trim|required|min_length[6]|max_length[10]');
			$this->form_validation->set_rules('confirm_password', 'Retype Password', 'required|matches[new_password]');
		   if ($this->form_validation->run() == TRUE)
				{
					
						 if($this->input->post() !='')
					    {
							$old_password =  $this->input->post('old_password');
							$new_password =  $this->input->post('new_password');
							$confirm_password =  $this->input->post('confirm_password');
							$table = "tbl_registration";
							//$this->db->model->checkOldPass()
							$result = $this->base_model->checkOldPass($table, $old_password);
							//echo $result; die;
							if($result){
								$query = $this->base_model->saveNewPass($table, $new_password);
								if($query){
								//redirect('change_password');
								 $this->session->set_flashdata('message', 'Your password is change successfully');
							     redirect(base_url('administration/resetpassword'));
								}else{
								 $this->session->set_flashdata('error', 'Your password is not updateed');
							     redirect(base_url('administration/resetpassword'));
								}
							}else{
								 $this->session->set_flashdata('error', 'Your old password is wrong Please enter right password');
							     redirect(base_url('administration/resetpassword'));
							}
							
						}
				}
			
			$data['title'] = "Reset Password";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/resetpassword');
			$this->load->view('admin/pages/footer');
		}	
		
		/* public function oldpassword_check($old_password){
			$user_id = $this->session->userdata('user_id');
		    $old_password_hash = md5($old_password);
			$old_password_db_hash = $this->db->get_where('tbl_registration',array('password'=>$old_password_hash,'user_id'=>$user_id))->row();
            
			//if(empty($old_password_db_hash)) {
              $oldpwd = $old_password_db_hash->password;			
           //   $oldpwd = $old_password_db_hash->password;			
			 if($old_password != $oldpwd)
			{ 
			   $this->form_validation->set_message('oldpassword_check', 'Old password not match');
			}
		} */
		
        public function add_teacher(){
			
			//echo "<pre>"; print_R($_POST); die;
			//teacher_name    mobile_number email gender  address
		  
			$this->login_check();
			$data = array();
			$errors = array();
			
			if($_POST)	 {
			    foreach($_POST['teacher_name'] as $key=>$val) {
				    if(empty($_POST['teacher_name'][$key])){
							$errors['teacher_name_'.$key] = 'Enter student name';				
					}	
					
                  	if(empty($_POST['mobile_number'][$key])){
							$errors['mobile_number_'.$key] = 'Enter student mobile number';				
					}elseif(strlen($_POST['mobile_number'][$key]) != 10){
						$errors['mobile_number_'.$key] = 'Plese enter  mobile number 10 digit';	
					}
				
					
					$resultdata = $this->db->get_Where('tbl_teacher', array('email'=>$_POST['email'][$key]))->row();	
				    if(!empty($resultdata)){
								$errors['email_'.$key] = 'Email id already exist';	
				    }else{
					if(empty($_POST['email'][$key])){
							$errors['email_'.$key] = 'Enter email';				
						}elseif(!filter_var($_POST['email'][$key], FILTER_VALIDATE_EMAIL)) {
							  $errors['email_'.$key] = "Invalid email"; 
						}
				    }
                   
                    if(empty($_POST['address'][$key])){
						 $errors['address_'.$key] = 'Enter address';	
				    }
                }		
                      $dupes = array_diff_key( $_POST['email'], array_unique($_POST['email'])); 	
					   if(!empty($dupes)) { 				  
						  foreach($dupes as $value=>$dupvalue){
							 $errors['email_'.$value] = "Duplicate invalid email"; 
						 }  	
					    }					 
				//echo "<pre>";  print_R($errors); die;	
				if(count($errors) > 0){
				//This is for ajax requests:
					if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
						echo json_encode($errors);
						exit;
					 }
				//This is when Javascript is turned off:
				//print_r($errors);
						   echo "<ul>";
						   foreach($errors as $key => $value){
						  echo "<li>" . $value . "</li>";
						   }
			 			   echo "</ul>";exit;
		        }else{
				//	teacher_name    mobile_number email gender  address
					foreach($_POST['teacher_name'] as $key=>$val) {
						
						$alphabet1 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
									$pass1 = array(); //remember to declare $pass as an array
									$alphaLength = strlen($alphabet1) - 1; //put the length -1 in cache
									for ($i = 0; $i < 8; $i++) {
										$n = rand(0, $alphaLength);
										$pass1[] = $alphabet1[$n];
									}
						
						
                             $teacher_name = $_POST['teacher_name'][$key];
                             $mobile_number = $_POST['mobile_number'][$key];
                             $email = $_POST['email'][$key];
                             $gender = $_POST['gender'][$key];
                             $address = $_POST['address'][$key];
							 $rand_number = implode($pass1);
							 $created_at  = date("Y-m-d h:i:s");

								$insertData =  array(
											 'teacher_name'=>$teacher_name,
											 'mobile_number'=>$mobile_number,
											 'email'=>$email,
											 'gender'=>$gender,
											 'address'=>$address,
											 'rand_number'=>$rand_number,
											 'created_at'=>$created_at
											);	

                        $from_email = "speechtotext@gmail.com"; 
						$name  = ucfirst($teacher_name);
                        $getemailid = base64_encode($email); 

									//$to_email = $email; 
					    $link1 = "http://mobileandwebsitedevelopment.com/speechlinklive/teacher/new_password?rdcd=".$rand_number.'&id='.$getemailid;
						
						$mesg  = "Hello " . $name."\n";							
						$mesg .= "You Have added as Teacher and Invited of Speech link.\n";
						$mesg .= "Please Reset Password click \n"; 
						$mesg .= $link1; 
						

						$this->load->library('email'); 

						$this->email->from($from_email); 
						$this->email->to($email);
						$this->email->subject('You have Invited speech link'); 
						$this->email->message($mesg); 
						$this->email->send();		 										
						$this->db->insert('tbl_teacher', $insertData);
                    }		
					  
				    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&  strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
						$errors['done']='success';
						//$errors['MSG']='Work order has been added successfully.';
						echo json_encode($errors);
						//redirect('masterForm/raw_material_master');
						exit;
				    }
					
					
				}  
			}
			
			$data['title'] = "Add Teacher";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/add_teacher');
			$this->load->view('admin/pages/footer');
		}	
		public function teacher_csvfile(){
			
			if(isset($_POST["submit"])){
				
             if($_FILES['file']['name'] != "") {				
				$filename = $_FILES['file']['tmp_name'];
				$file_check = $_FILES['file']['name'];

				 if($_FILES["file"]["size"] > 0)
				{
						 //if ($file_check != ""){
						/*  $file_ext=strtolower(end(explode('.',$_FILES['file']['name'])));
								 $expensions= array("csv");
								 if(in_array($file_ext,$expensions)){ */
						  $file = fopen($filename, "r");
						  $c = 0;
						  $d = 0;
						  $valid_e = 0;
				while (($emapData = fgetcsv($file, 10000, ",")) != FALSE) {	  
					  if(filter_var($emapData[2], FILTER_VALIDATE_EMAIL)) {
						  
						$checkemailexit = $this->db->get_Where('tbl_teacher',array('email'=>$emapData[2]))->row();  
						 
						if(empty($checkemailexit)) {
                         
						$alphabet1 = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
									$pass1 = array(); //remember to declare $pass as an array
									$alphaLength = strlen($alphabet1) - 1; //put the length -1 in cache
									for ($i = 0; $i < 8; $i++) {
										$n = rand(0, $alphaLength);
										$pass1[] = $alphabet1[$n];
									}

                    
                   
						    $rand_number = implode($pass1);
						    $created_at  = date("Y-m-d h:i:s");
							$insertData  =  array(
											'teacher_name'=>$emapData[0],
											'mobile_number'=>$emapData[1],
											'email'=>$emapData[2],
											'gender'=>$emapData[3],
											'address'=>$emapData[4],
											'rand_number'=>$rand_number,
											'created_at'=>$created_at
										);
										
								$c = $c + 1;
								
								
							$from_email = "speechtotext@gmail.com"; 
							//$to = "pankajmobapps@gma"; 
							$rand_number = $rand_number; 
							//$getemail = $userdata->email; 
							$getemailid = base64_encode($emapData[2]); 

							//$to_email = $email; 
							 $link1 = "http://mobileandwebsitedevelopment.com/speechlinklive/teacher/new_password?rdcd=".$rand_number.'&id='.$getemailid;
							//Load email library 
							//$clicklink  ="<a href='$link'>Click Here</a>";
							$name  = ucfirst($emapData[0]);

							/* $mesg  = "Hello " . $name;
							$mesg .= "<BR>";
							$mesg .= "Click on this link to reset your password .";
							$mesg .= "Reset Password ".$clicklink; */


							$mesg  = "Hello " . $name."\n";							
							$mesg .= "You Have added as Teacher and Invited of Speech link.\n";
							$mesg .= "Please Reset Password click \n"; 
							$mesg .= $link1; 


							$this->load->library('email'); 

							$this->email->from($from_email); 
							$this->email->to($emapData[2]);
							$this->email->subject('You have Invited speech link as Teacher'); 
							$this->email->message($mesg); 
							$this->email->send();
							$this->db->insert('tbl_teacher', $insertData);	
							}else{
							  $d = $d + 1;
							  continue;
							}
						}
					}
					fclose($file);
					$this->session->set_flashdata('message', "You database has imported successfully. You have inserted $c recoreds and duplicate email and invalid email is $d ");
					redirect(base_url('administration/add_teacher'));				 
				}}else{
					 $this->session->set_flashdata('error', 'Please Select File.');
					 redirect(base_url('administration/add_teacher'));
				}	
		    }
		}
		
		public function delete_teacher(){
			
			if(isset($_GET['teacher_id'])){
			$teacherid = base64_decode(base64_decode(base64_decode($_GET['teacher_id']))); 
			//$this->db->where('student_id',$studentid);
			 $this->db->delete('tbl_teacher',array('teacher_id'=>$teacherid));
			 $this->session->set_flashdata('message', 'One row delete successfully');
			 redirect(base_url('administration/teachers'));
			}
		} 
		
		public function edit_teacher(){
			
			$data = array();
			if(isset($_GET['teacher_id'])){
				$teacher_id = base64_decode(base64_decode(base64_decode($_GET['teacher_id']))); 
				$data['teachelistdata'] = $this->db->get_where('tbl_teacher',array('teacher_id'=>$teacher_id))->row();
			}
			 $this->form_validation->set_rules('teacher_name', 'teacher name', 'trim|required');
			 $this->form_validation->set_rules('mobile_number', 'mobile number', 'trim|required');
			 $this->form_validation->set_rules('email', 'email', 'trim|required');
			 $this->form_validation->set_rules('address', 'address', 'trim|required');
			
			 if ($this->form_validation->run() == TRUE)
				{
					
					 	 if($this->input->post() !='')
					    {
					          $teacher_id     =  $this->input->post('teacher_id');
					          $teacher_name   =  $this->input->post('teacher_name');
					          $mobile_number  =  $this->input->post('mobile_number');
					          $gender         =  $this->input->post('gender');
					          $email          =  $this->input->post('email');
					          $address        =  $this->input->post('address');
									
									$updatedata =  array(
											 'teacher_name'=>$teacher_name,
											 'mobile_number'=>$mobile_number,
											 'email'=>$email,
											 'gender'=>$gender,
											 'address'=>$address
											);	
									
						$this->db->where('teacher_id',$teacher_id);
                        $this->db->update('tbl_teacher',$updatedata);
						$this->session->set_flashdata('message', "One teacher has been update successfully");	
							redirect(base_url('administration/teachers'));  
						}
				} 
			
			
			$data['title'] = "Edit teacher";
  // echo "<pre>";			print_R($data); 
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/edit_teacher',$data);
			$this->load->view('admin/pages/footer');
		}
		
		
	    public function add_class(){
			
			$this->login_check();
			$data = array();
			$data['classlist'] = $this->db->get('tbl_class')->result();
			$data['title'] = "Add Class";
			
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/add_class',$data);
			$this->load->view('admin/pages/footer');
		}	
		public function add_lecture(){
			
			$this->login_check();
			$data = array();
			$data['classlist'] = $this->db->get('tbl_class')->result();
			$data['teacherlist'] = $this->db->get('tbl_teacher')->result();
			            $this->db->select('*');
						$this->db->from('tbl_lecture');
						$this->db->order_by('lecture_id', 'desc');
						$query = $this->db->get();
			$data['lecturelist'] = $query->result();
			
			$data['title'] = "Add Lecture";
			$this->load->view('admin/pages/header',$data);
			$this->load->view('admin/pages/add_lecture',$data);
			$this->load->view('admin/pages/footer');
		}	
		
		public function addteacher()
		{
			$data = array();
			$data['divsize']=$_POST['divSize'];
			$this->load->view('admin/includes/addteacher',$data);
		}
		public function insertclass()
		{
			//print_R($_POST);
			if($_POST['classname']) {
				$data = array(); 
				$result = array(); 
			                 $classname = $_POST['classname'];
							 $created_at  = date("Y-m-d h:i:s");

								$insertData =  array(
											 'classname'=>$classname,
											 'created_at'=>$created_at
										);	
					$query = $this->db->insert('tbl_class',$insertData);	
              if($query){
				 $data['classlist'] = $this->db->get('tbl_class')->result();
				  $result['res'] =  $this->load->view('admin/includes/classname',$data);
				
			  }					
			}
		}
		
		public function delete_class(){
			
			$data  =array();
			if(isset($_POST['class_id'])){
			$class_id = base64_decode(base64_decode(base64_decode($_POST['class_id']))); 
			//$this->db->where('student_id',$studentid);
			$query =  $this->db->delete('tbl_class',array('class_id'=>$class_id));
			if($query){
				 $data['classlist'] = $this->db->get('tbl_class')->result();
				  $result['res'] =  $this->load->view('admin/includes/classname',$data);
				
			  }	
			}
		} 
		
		public function updateclassdata(){
			
		     $data  =array();
			if(isset($_POST['classid'])){
				 $class_id = base64_decode(base64_decode(base64_decode($_POST['classid']))); 
				 $editclaasname = $_POST['editclaasname'];
				 $updatedata =  array('classname'=>$editclaasname);	
				 $this->db->where('class_id',$class_id);
                 $query =   $this->db->update('tbl_class',$updatedata);
				if($query){
				  $data['classlist'] = $this->db->get('tbl_class')->result();
				  $result['res'] =  $this->load->view('admin/includes/classname',$data);
				
			    }  	
				
		     }  
		}
		
		public function add_lecturedata(){
		
			if($_POST) {
				$data = array(); 
				$result = array(); 
			                 $teacher_id = $_POST['teacherid'];
			                 $class_id = $_POST['classid'];
			                 $lecture_name = $_POST['lecturename'];
							 $created_at  = date("Y-m-d h:i:s");

								$insertData =  array(
											 'teacher_id'=>$teacher_id,
											 'class_id'=>$class_id,
											 'lecture_name'=>$lecture_name,
											 'created_at'=>$created_at
										);	
					$query = $this->db->insert('tbl_lecture',$insertData);	
            if($query){
						$this->db->select('*');
						$this->db->from('tbl_lecture');
						$this->db->order_by('lecture_id', 'desc');
						$query = $this->db->get();
						$data['lecturelist'] = $query->result();
				   //$data['lecturelist'] =   $this->db->select()->from('tbl_lecture')->order_by('lecture_id', 'desc')->result();
				  $result['res'] =  $this->load->view('admin/includes/lecturelist',$data);
			  }					
			}
		}
		
		public function delete_lecture(){
			
			$data  =array();
			if(isset($_POST['lectureid'])){
			$lectureid = base64_decode(base64_decode(base64_decode($_POST['lectureid']))); 
			//$this->db->where('student_id',$studentid);
			$query =  $this->db->delete('tbl_lecture',array('lecture_id'=>$lectureid));
			if($query){
				       $this->db->select('*');
						$this->db->from('tbl_lecture');
						$this->db->order_by('lecture_id', 'desc');
						$query = $this->db->get();
						$data['lecturelist'] = $query->result();
				  //$data['lecturelist'] = $this->db->get('tbl_lecture')->result();
				  $result['res'] =  $this->load->view('admin/includes/lecturelist',$data);
				
			  }	
			}
		} 
		
		public function Editlecturename(){
			
			$data = array();
			if(isset($_POST['lectureid'])){
			$lectureid = base64_decode(base64_decode(base64_decode($_POST['lectureid']))); 
			//$this->db->where('student_id',$studentid);
			$data['classlist'] = $this->db->get('tbl_class')->result();
			$data['teacherlist'] = $this->db->get('tbl_teacher')->result();
			
			$data['getlecturedata'] =  $this->db->get_where('tbl_lecture',array('lecture_id'=>$lectureid))->row();
			$this->load->view('admin/includes/editlecture.php',$data);
			}
		}
		
		public function updatelacture(){
		   
		    if($_POST) {
				$data = array(); 
				$result = array(); 
			                 $lecture_id = $_POST['lectureid'];
			                 $teacher_id = $_POST['teacherid'];
			                 $class_id = $_POST['classid'];
			                 $lecture_name = $_POST['lecturename'];
							 $created_at  = date("Y-m-d h:i:s");

								$updatedata =  array(
											 'teacher_id'=>$teacher_id,
											 'class_id'=>$class_id,
											 'lecture_name'=>$lecture_name,
											 'created_at'=>$created_at
										);	
										
			     	$this->db->where('lecture_id',$lecture_id);
					$query = $this->db->update('tbl_lecture',$updatedata);	
				    if($query){
							$this->db->select('*');
							$this->db->from('tbl_lecture');
							$this->db->order_by('lecture_id', 'desc');
							$query = $this->db->get();
							$data['lecturelist'] = $query->result();
					   //$data['lecturelist'] =   $this->db->select()->from('tbl_lecture')->order_by('lecture_id', 'desc')->result();
					  $result['res'] =  $this->load->view('admin/includes/lecturelist',$data);
				    }					
			} 		   
			
		}
		
		//public  function change_password()
		
    }
