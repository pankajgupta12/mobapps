<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Teacher extends CI_Controller {

       function __Construct(){
        parent::__Construct();
			$this->load->model('base_model');
			$this->load->helper(array('form', 'url','superadmin'));
			//$this->load->helper('download');
			//$this->load->library('session');
			date_default_timezone_set("Asia/Kolkata");
             
        }
		
	  	public function index()
		{
			
			$data =array();
			$data['title']  ='Teacher Login';
			$this->load->view('admin/login/teacher/header1', $data);
			$this->load->view('admin/login/teacher/index', $data);
			$this->load->view('admin/login/teacher/footer1', $data);
			
		} 
		
		public function login(){
			$this->form_validation->set_rules('teacher_loginname', 'Email', 'trim|required|valid_email');
			$this->form_validation->set_rules('teacher_password', 'Password', 'trim|required');
			
			 if ($this->form_validation->run() == TRUE)
				{
					
					 	 if($this->input->post() !='')
					    {
					          $student_email =  $this->input->post('teacher_loginname');
						      $password =  md5($this->input->post('teacher_password'));
							  
							$this->db->select('*');
							$this->db->from('tbl_teacher');
							$this->db->where('email',$student_email);
							$this->db->where('password',$password);  
							$this->db->where('status','1');  
							$query = $this->db->get();
						 //	echo $this->db->last_query(); die;
							if($query->num_rows() == 1)
							{
								$data = array();
								$row=$query->row();
								
										$data=array(
										'teacher_id'=>$row->teacher_id,
										'teacher_email'=>$row->email,
										'teacher_name'=>$row->teacher_name,
										'teacher_logout_time'=>$row->logout_time
										);
										
								$this->session->set_userdata($data);           
							    redirect(base_url('teacher/teacher_dashbord'));
							}
							else
							{
							  $this->session->set_flashdata('error', 'Your email and password is wrong.');
							   redirect(base_url('teacher/index'));
							}  
					    } 
				}	   
		    $data['title'] = "Teacher Login";
			$this->load->view('admin/login/teacher/header1', $data);
			$this->load->view('admin/login/teacher/index', $data);
			$this->load->view('admin/login/teacher/footer1', $data);
		}
		
		public function new_password(){
			if(isset($_GET['rdcd']) && isset($_GET['id']))
			{ 
		            $randID = ($_GET['rdcd']);
					$emailid = trim(base64_decode($_GET['id']));
					
		        $checkstudentid = $this->db->get_where('tbl_teacher',array('rand_number'=>$randID,'status'=>'0'))->row();
					//	echo $this->db->last_query(); die;
							
				if(!empty($checkstudentid)){
					
					$this->form_validation->set_rules('password', 'New Password', 'trim|required|min_length[6]|max_length[10]');
					$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');
				   
					 if ($this->form_validation->run() == TRUE)
					{
						
						 if($this->input->post() !='')
						{
								$password =  $this->input->post('password');
								$confirm_password =  $this->input->post('confirm_password');
								
								$this->db->where('email',$emailid);
								$this->db->update('tbl_teacher',array('password'=>md5($confirm_password),'status'=>'1'));
								
								
								
						    $this->db->select('*');
							$this->db->from('tbl_teacher');
							$this->db->where('rand_number',$randID);
							$this->db->where('password',md5($confirm_password));  
							$this->db->where('status','1');  
							$query = $this->db->get();
						 	if($query->num_rows() == 1)
							{
								$data = array();
								$row=$query->row();
								
										$data=array(
										'teacher_id'=>$row->teacher_id,
										'teacher_email'=>$row->email,
										'teacher_name'=>$row->teacher_name,
										'teacher_logout_time'=>$row->logout_time
										);
										
								$this->session->set_userdata($data);           
							    redirect(base_url('teacher/teacher_dashbord'));
							}
							else
							{
								  $this->session->set_flashdata('message', 'Your email and password is wrong.');
								  redirect(base_url('teacher/somethingwromg'));
							}	
						}
					}
				}
				else
				{
					redirect(base_url('teacher/somethingwromg'));
				} 	
			}
			
			$data =array();
			$data['title']  ='Reset Password';
			$this->load->view('admin/login/teacher/header1', $data);
			$this->load->view('admin/login/teacher/new_password', $data);
			$this->load->view('admin/login/teacher/footer1', $data);
  		}
		
		public function somethingwromg(){
		  echo "Something wrong please contact speechlink"; 
		}
		
		public function teacher_dashbord(){
			
			//print_r($_SESSION);
			$this->login_teachercheck();
			$data = array();
			 $data['title']  = "Teacher Dashbord";
			$this->load->view('admin/login/teacher/header', $data);
			$this->load->view('admin/login/teacher/teacher_dashbord', $data);
			$this->load->view('admin/login/teacher/footer', $data); 
		}
		
		function logout()
		{
			$this->db->where('teacher_id',$this->session->userdata('teacher_id'));
			$this->db->update('tbl_teacher',array('logout_time'=>date("Y-m-d h:i:s")));
			
			unset($_SESSION['teacher_id']);
			unset($_SESSION['teacher_email']);
			unset($_SESSION['teacher_name']);
			unset($_SESSION['teacher_logout_time']);

			redirect(base_url('teacher/index'));
		}
		
        public function login_teachercheck()
		{
				if($this->session->userdata('teacher_id') == "" && $this->session->userdata('teacher_email') =="") { 
					  redirect(base_url('teacher/index'));
				}
		}
	}
	
	?>